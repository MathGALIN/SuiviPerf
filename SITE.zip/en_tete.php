<?php

	
	//On obtient l'adresse
	  if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') 
		$adresse = "https"; 
	  else
		$adresse = "http"; 
		
	  // Ajoutez // à l'URL.
	  $adresse .= "://"; 
		
	  // Ajoutez l'hôte (nom de domaine, ip) à l'URL.
	  $adresse .= $_SERVER['HTTP_HOST']; 
		
	  // Ajouter l'emplacement de la ressource demandée à l'URL
	  $fichier = $_SERVER['REQUEST_URI']; 
	  $longueur_fichier = strlen($fichier);
	  $flag = 0;
	  for ($i = 0; $i < $longueur_fichier; $i++)
	  {
		  if ($flag < 2)
		  {
			$adresse .= $fichier[$i];
		  }
		  
		  if ($fichier[$i] == '/')
		  {
			  $flag += 1;
		  }
	  } 
	  
	
	
	$existeCookie = isset($_COOKIE['connecter']) ;
	$cookienul = "";
	if ($existeCookie == true)
	{
		$valeur = $_COOKIE['connecter'];
		
		if ($valeur == "")
		{
			$cookienul = true;
		}
	}
	
	if (	$existeCookie == false || $cookienul == true	)
	{
		$message = "Connectez vous pour accéder au site";
		echo "
		<script>
			document.location.href = '$adresse/UTILISATEUR/connexion.php?message=$message';
		</script>
		";
	}
?>

<?php
//On dirige vers fontawesome qui est installé localement
echo "
<link href='$adresse/Framework/font-awesome/css/all.css' rel='stylesheet'>
";






//On inclue l'installation de bootstrap 

//Le CSS
echo "
<link 
href='$adresse/Framework/bootstrap/bootstrap.min.css' 
rel='stylesheet'
integrity='sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3' 
crossorigin='anonymous'>
";

//Le javascript
echo "
<script 
src='$adresse/Framework/bootstrap/js/bootstrap.bundle.min.js' 
integrity='sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p' 
crossorigin='anonymous'>
</script>
";

//Installe le favicon
echo "
<link rel='shortcut icon' type='image/x-icon' href='$adresse/img/favicon.ico'>
";
?>

<title> SuiviPerf </title>

<div align='center' id='div_en_tente'>
	
	<div id='en_tete'>
		<?php
			echo "
			SuiviPerf <a href='".$adresse."index.php'> 
			<i class='fas fa-home'></i> 
			</a>
			";
		?>
	</div>



	<div align='left' id='sous_en_tete'>
		Vous êtes connecter en tant que 
		<?php 
			echo $_COOKIE['connecter'];
			echo "
			<a href='".$adresse."deconnexion.php'> 
			<i class='fas fa-sign-out-alt'> </i>
			</a>
			";
		?>
	</div>

</div>






<style>
	h1 {
		color: black;
		margin-left: 20px;
	}

	h2 {
		color: black;
		margin-left: 50px;
	}
	
	h3 {
		color: black;
		margin-left: 90px;
	}

	p {
		margin-left:  50px;
		margin-bottom: -10px;
	}


	a {
		color: purple;
		margin-left: 50px;
	}
	
	a:link 
	{ 
		text-decoration:none; 
	} 
	
	input[type="submit"]{
		font-size: 30px;
	}
	
	#div_en_tente {
		position: -webkit-sticky;
		position: sticky;
		top: 0px;
		z-index: 10;
	}

	#en_tete {
		background: orange;
		font-size: 40px; 
		color: ghostwhite;
	}

	#sous_en_tete {
		background: seagreen;
		font-size: 20px; 
		color: ghostwhite;
		
		position: -webkit-sticky;
		position: sticky;
		top: 0px;
	}
	





	.card {
	/* La transition s'applique à la fois sur la largeur et la hauteur, avec une durée d'une seconde. */
	-webkit-transition: all 1s ease; /* Safari et Chrome */
	-moz-transition: all 1s ease; /* Firefox */
	-ms-transition: all 1s ease; /* Internet Explorer 9 */
	-o-transition: all 1s ease; /* Opera */
	transition: all 1s ease;
	}
	.card:hover {
	/* L'image est grossie de 25% */
	-webkit-transform:scale(1.25); /* Safari et Chrome */
	-moz-transform:scale(1.25); /* Firefox */
	-ms-transform:scale(1.25); /* Internet Explorer 9 */
	-o-transform:scale(1.25); /* Opera */
	transform:scale(1.25);
	z-index: 2;
	}
	
	.card:active {
		background: pink;
	}

</style>