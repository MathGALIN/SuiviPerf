<title>SuiviPerf - Accueil</title>
<?php include("en_tete.php"); ?>

<style>
body {
    font-family: 'Arial', sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 0;
}

h1.main-title {
    margin-top: 30px;
    text-align: center;
    color: #333;
}

table.lignesEspacees {
    border-collapse: separate;
    border-spacing: 20px;
}

.card {
    width: 22rem;
    height: 25rem;
    border: 2px solid black;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    cursor: pointer;
    transition: transform 0.3s, box-shadow 0.3s;
    background-color: #fff;
    display: flex;
    flex-direction: column;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 25px rgba(0,0,0,0.25);
}

.card-img-top {
    width: 100%;
    height: 60%;
    object-fit: cover;
    border-bottom: 1px solid #ddd;
}

.card-content {
    flex: 1;
    display: flex;
    justify-content: center; /* centre horizontalement */
    align-items: center;     /* centre verticalement */
}

.card-title {
    display: block;
    text-align: center;       /* centrage horizontal exact */
    font-size: 1.2rem;
    font-weight: 600;
    color: #007bff;
    margin: 0;
    padding: 0 10px;
    box-sizing: border-box;
}

#4 h1 {
    cursor: pointer;
    color: #007bff;
    transition: color 0.3s;
}

#4 h1:hover {
    color: #0056b3;
}
</style>

<h1 class="main-title">Veuillez choisir un contenu</h1>
<hr>
<br>

<!-- Page principale -->
<div id='0'>
    <table align='center' class='lignesEspacees'>
        <tr>
            <td onclick='ouvrir(1, 0)'>
                <div class='card'>
                    <img class='card-img-top' src='img/entrainement.png' alt='Photo'>
                    <div class='card-content'>
                        <h1 class='card-title'>Entrainement</h1>
                    </div>
                </div>
            </td>
            <td onclick='ouvrir(3, 0)'>
                <div class='card'>
                    <img class='card-img-top' src='img/alimentation.png' alt='Photo'>
                    <div class='card-content'>
                        <h1 class='card-title'>Alimentation</h1>
                    </div>
                </div>
            </td>
            <td onclick='ouvrir(2, 0)'>
                <div class='card'>
                    <img class='card-img-top' src='img/statistiques.png' alt='Photo'>
                    <div class='card-content'>
                        <h1 class='card-title'>Statistiques</h1>
                    </div>
                </div>
            </td>
        </tr>
    </table>
</div>

<!-- Sous-pages -->
<div id='1' style='display: none;'>
    <table align='center' class='lignesEspacees'>
        <tr>
            <td onclick='ouvrirURL(11)'>
                <div class='card'>
                    <img class='card-img-top' src='img/muscuSolo.png' alt='Photo'>
                    <div class='card-content'>
                        <h1 class='card-title'>Ses entraînements</h1>
                    </div>
                </div>
            </td>
            <td onclick='ouvrirURL(12)'>
                <div class='card'>
                    <img class='card-img-top' src='img/muscuPlusieurs.png' alt='Photo'>
                    <div class='card-content'>
                        <h1 class='card-title'>Entraînements partagés</h1>
                    </div>
                </div>
            </td>
            <td onclick='ouvrirURL(13)'>
                <div class='card'>
                    <img class='card-img-top' src='img/creerEntrainement.png' alt='Photo'>
                    <div class='card-content'>
                        <h1 class='card-title'>Créer son entraînement</h1>
                    </div>
                </div>
            </td>
        </tr>
    </table>
</div>

<div id='2' style='display: none;'>
    <table align='center' class='lignesEspacees'>
        <tr>
            <td onclick='ouvrirURL(21)'>
                <div class='card'>
                    <img class='card-img-top' src='img/strongman.png' alt='Photo'>
                    <div class='card-content'>
                        <h1 class='card-title'>Voir ses performances</h1>
                    </div>
                </div>
            </td>
            <td onclick='ouvrirURL(22)'>
                <div class='card'>
                    <img class='card-img-top' src='img/noterPoids.png' alt='Photo'>
                    <div class='card-content'>
                        <h1 class='card-title'>Noter son poids</h1>
                    </div>
                </div>
            </td>
            <td onclick='ouvrirURL(23)'>
                <div class='card'>
                    <img class='card-img-top' src='img/voirPoids.png' alt='Photo'>
                    <div class='card-content'>
                        <h1 class='card-title'>Évolution du poids</h1>
                    </div>
                </div>
            </td>
        </tr>
        <tr>
            <td onclick='ouvrirURL(24)'>
                <div class='card'>
                    <img class='card-img-top' src='img/edt.png' alt='Photo'>
                    <div class='card-content'>
                        <h1 class='card-title'>Voir emploi du temps</h1>
                    </div>
                </div>
            </td>
            <?php
            if ($_COOKIE["aMontre"] == 1 ) {
                echo "
                <td onclick='ouvrirURL(25)'>
                    <div class='card'>
                        <img class='card-img-top' src='img/VoirMontre.png' alt='Photo'>
                        <div class='card-content'>
                            <h1 class='card-title'>Voir information montre</h1>
                        </div>
                    </div>
                </td>
                <td onclick='ouvrirURL(26)'>
                    <div class='card'>
                        <img class='card-img-top' src='img/EnregistrerMontre.png' alt='Photo'>
                        <div class='card-content'>
                            <h1 class='card-title'>Enregistrer information montre</h1>
                        </div>
                    </div>
                </td>
                ";
            }
            ?>
        </tr>
    </table>
</div>

<div id='3' style='display: none;'>
    <table align='center' class='lignesEspacees'>
        <tr>
            <td onclick='ouvrirURL(31)'>
                <div class='card'>
                    <img class='card-img-top' src='img/voirAliments.png' alt='Photo'>
                    <div class='card-content'>
                        <h1 class='card-title'>Voir les aliments</h1>
                    </div>
                </div>
            </td>
        </tr>
    </table>
</div>

<div id='4' style='display: none;'>
    <br>
    <h1 onclick='fermer()'>
        RETOUR ARRIERE <i class='fas fa-backspace'></i>
    </h1>
</div>

<script>
function ouvrir(Nid_apparaitre, Nid_disparaitre) {
    document.getElementById(Nid_apparaitre).style.display = '';
    document.getElementById(4).style.display = '';
    document.getElementById(Nid_disparaitre).style.display = 'none';
}

function fermer() {
    document.getElementById(0).style.display = '';
    document.getElementById(1).style.display = 'none';
    document.getElementById(2).style.display = 'none';
    document.getElementById(3).style.display = 'none';
    document.getElementById(4).style.display = 'none';
}

function ouvrirURL(URL) {
    const urls = {
        11: 'ENTRAINER/entrainement.php?partage=0',
        12: 'ENTRAINER/entrainement.php?partage=1',
        13: 'CREATION/entrainement.php',
        21: 'VOIRPERF/perfCategorie.php',
        22: 'NOTERPOIDS/noterPoids.php',
        23: 'EVOLUTIONPOIDS/EvolutionPoids.php',
        24: 'EDT/EDT.php',
        25: 'MONTRE/voir.php',
        26: 'MONTRE/enregistrer.php',
        31: 'ALIMENTATION/VoirAliments.php'
    };
    if (urls[URL]) document.location.href = urls[URL];
}
</script>
