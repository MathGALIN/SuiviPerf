-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  jeu. 17 fév. 2022 à 17:36
-- Version du serveur :  5.7.17
-- Version de PHP :  5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `SuiviPerf`
--

-- --------------------------------------------------------

--
-- Structure de la table `aliment`
--

CREATE TABLE `aliment` (
  `IdAliment` int(11) NOT NULL,
  `IdCategorieA` int(11) NOT NULL,
  `LibelleAliment` text NOT NULL,
  `Unite` text NOT NULL,
  `ProtParUnite` int(11) NOT NULL,
  `photo` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `aliment`
--

INSERT INTO `aliment` (`IdAliment`, `IdCategorieA`, `LibelleAliment`, `Unite`, `ProtParUnite`, `photo`) VALUES
(1, 1, 'Oeuf de poule', 'par oeuf', 13, 'oeuf.png'),
(2, 1, 'Steak de boeuf', 'pour 100 grammes', 25, 'steak_boeuf.png'),
(3, 2, 'Bol de lait', 'par Bol (300ml)', 10, 'lait.png'),
(4, 1, 'Cuisse poulet', 'par cuisse de poulet (100g)', 24, 'cuisse_poulet.png'),
(5, 2, 'Camembert', 'par Camembert (100g)', 20, 'camembert.png'),
(6, 3, 'Sardine', 'par sardine (100g)', 25, 'sardine.png'),
(7, 1, 'Agneau', 'pour 100 grammes', 25, 'agneau.png'),
(8, 1, 'Lapin', 'pour 100 grammes', 33, 'lapin.png'),
(9, 1, 'Porc', 'pour 100 grammes', 27, 'porc.png'),
(10, 3, 'Saumon', '100 grammes', 25, 'saumon.png'),
(11, 3, 'Thon', 'pour 100 grammes', 30, 'thon.png'),
(12, 5, 'Ail', 'Pour 100 grammes', 6, 'ail.png'),
(14, 1, 'Canard', 'par gramme (100g)', 31, 'canard.png'),
(13, 2, 'Parmesan', 'pour 100 grammes', 38, 'parmesan.png'),
(15, 4, 'amandes', 'pour 100 grammes', 23, 'amandes.png'),
(16, 5, 'cacahuètes', 'pour 100 grammes', 29, 'cacahuete.png'),
(17, 4, 'Pruneaux', 'Pour 100 grammes', 2, 'pruneaux.png'),
(18, 3, 'Anchois', 'pour 100 grammes', 29, 'anchois.png'),
(19, 2, 'Gruyere rape', 'pour 100 grammes', 30, 'gruyere.png');

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `NumCategorie` int(11) NOT NULL,
  `LibelleCategorie` text NOT NULL,
  `PoidsCategorieHaltere` text NOT NULL,
  `PoidsCategorieLest` int(11) NOT NULL,
  `PoidsCategorieElastique` int(11) NOT NULL DEFAULT '0',
  `NumEntrainement` int(11) NOT NULL,
  `pseudo` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`NumCategorie`, `LibelleCategorie`, `PoidsCategorieHaltere`, `PoidsCategorieLest`, `PoidsCategorieElastique`, `NumEntrainement`, `pseudo`) VALUES
(6, 'Etirement fin', '0', 0, 0, 1, 'Line'),
(4, 'Push', '20', 0, 45, 1, 'Line'),
(5, 'Leg', '0', 0, 22, 1, 'Line'),
(3, 'pull', '0', 0, 60, 1, 'Line'),
(1, 'Etirement', '20', 8, 0, 1, 'Line'),
(2, 'Abdo', '0', 5, 0, 4, 'Line'),
(1, 'Echauffement', '20', 5, 0, 4, 'Line'),
(3, 'pull', '0', 5, 0, 4, 'Line'),
(4, 'Push', '15', 5, 0, 4, 'Line'),
(5, 'Leg', '20', 5, 0, 4, 'Line'),
(6, 'Etirement', '0', 0, 0, 4, 'Line'),
(2, 'Abdo', '0', 8, 0, 1, 'Line'),
(1, 'Etirement + Farmer walk', '20', 8, 0, 2, 'Line'),
(2, 'Abdo', '20', 8, 0, 2, 'Line'),
(3, 'pull', '0', 0, 60, 2, 'Line'),
(4, 'Push', '20', 7, 45, 2, 'Line'),
(5, 'Leg', '1', 1, 1, 2, 'Line'),
(6, 'Etirement', '0', 0, 0, 2, 'Line'),
(1, 'Echauffement', '0', 0, 0, 5, 'Line'),
(2, 'Trapeze', '0', 0, 35, 5, 'Line'),
(3, 'Abdo', '0', 0, 25, 5, 'Line'),
(4, 'pull', '0', 0, 35, 5, 'Line'),
(5, 'Push', '0', 0, 25, 5, 'Line'),
(6, 'Leg', '0', 0, 50, 5, 'Line'),
(7, 'Etirement', '0', 0, 0, 5, 'Line');

-- --------------------------------------------------------

--
-- Structure de la table `categoriealiment`
--

CREATE TABLE `categoriealiment` (
  `IdCategorieA` int(11) NOT NULL,
  `LibelleCategorie` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `categoriealiment`
--

INSERT INTO `categoriealiment` (`IdCategorieA`, `LibelleCategorie`) VALUES
(1, 'Viande'),
(2, 'Laitage'),
(3, 'Poisson'),
(4, 'Fruits'),
(5, 'Légumes');

-- --------------------------------------------------------

--
-- Structure de la table `entrainement`
--

CREATE TABLE `entrainement` (
  `NumEntrainement` int(11) NOT NULL,
  `Libelle` text NOT NULL,
  `Type` text NOT NULL,
  `pseudo` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `entrainement`
--

INSERT INTO `entrainement` (`NumEntrainement`, `Libelle`, `Type`, `pseudo`) VALUES
(1, 'Séance longue 1', 'Journalier 1', 'Line'),
(2, 'Séance longue 2', 'Journalier 2', 'Line'),
(3, 'Séance courte 1', 'Classique court', 'Line'),
(4, 'Séance courte 2', 'Au poids du corps (et un peu haltere)', 'Line'),
(5, 'Elastique', 'PDM', 'Line');

-- --------------------------------------------------------

--
-- Structure de la table `exercice`
--

CREATE TABLE `exercice` (
  `NumExercice` int(11) NOT NULL,
  `NbSerie` int(11) NOT NULL,
  `LibelleExercice` text NOT NULL,
  `TempsExercice` int(11) NOT NULL,
  `IsEval` tinyint(1) NOT NULL,
  `isPDC` int(11) NOT NULL DEFAULT '0',
  `image` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `exercice`
--

INSERT INTO `exercice` (`NumExercice`, `NbSerie`, `LibelleExercice`, `TempsExercice`, `IsEval`, `isPDC`, `image`) VALUES
(1, 1, 'Etirement poignet', 30, 0, 0, 'etirement.png'),
(2, 1, 'Etirement tete et cou', 30, 0, 0, 'etirement.png'),
(3, 0, 'Etirement epaule', 30, 0, 0, 'etirement.png'),
(4, 1, 'Etirement coude', 30, 0, 0, 'etirement.png'),
(5, 1, 'Etirement dos', 30, 0, 0, 'etirement.png'),
(6, 1, 'Etirement cuisse', 30, 0, 0, 'etirement.png'),
(7, 1, 'Etirement cheville', 30, 0, 0, 'etirement.png'),
(8, 1, 'Etirement ischio', 30, 0, 0, 'etirement.png'),
(9, 5, 'Marche du fermier', 60, 1, 1, 'MarcheFermier.png'),
(10, 1, 'Flexion laterale', 60, 0, 1, 'FlexionLaterale.png'),
(11, 1, 'Rotation du buste', 60, 0, 1, 'RotationDuBuste.png'),
(12, 1, 'Montee de genou', 60, 0, 1, 'MonteeDeGenou.png'),
(13, 1, 'Chop rotatif', 60, 0, 0, 'ChopRotatif.png'),
(14, 3, 'Gainage', 60, 0, 1, 'Gainage.png'),
(15, 5, 'Crunch', 60, 0, 1, 'Crunch.png'),
(16, 5, 'Curl marteau', 60, 1, 0, 'CurlMarteau.png'),
(17, 5, 'Curl classique', 60, 1, 0, 'Curl.png'),
(18, 1, 'Handgripper', 120, 0, 0, 'HandGripper.png'),
(19, 1, 'Traction (5)', 300, 1, 1, 'Traction.png'),
(20, 5, 'Extension triceps', 60, 1, 0, 'Triceps.png'),
(21, 5, 'Extension triceps une main', 60, 1, 0, 'TricepsMain.png'),
(22, 5, 'Développe militaire', 60, 1, 0, 'DM.png'),
(23, 5, 'Developpe couche', 60, 1, 0, 'DC.png'),
(24, 3, 'Pompe', 60, 1, 1, 'Pompe.png'),
(25, 5, 'Fire hidrant', 60, 1, 0, 'FireHidrant.png'),
(26, 3, 'Squat', 60, 1, 1, 'Squat.png'),
(27, 3, 'Fente', 60, 1, 1, 'Fente.png'),
(28, 5, 'Souleve de terre', 60, 1, 1, 'Sdt.png'),
(29, 5, 'Mollet', 60, 1, 1, 'Chameau.png'),
(30, 5, 'Mollet 1 jambe', 60, 1, 1, 'Chameau1.png'),
(31, 1, 'Traction australienne', 300, 1, 1, 'TractionAustralienne.png'),
(32, 3, 'Pompe diamant', 60, 1, 1, 'PompeDiamant.png'),
(0, 1, 'REPOS', 60, 0, 0, 'repos.png'),
(33, 5, 'Ab wheel', 60, 1, 1, 'Wheel.png'),
(34, 2, 'Elevation laterale', 60, 1, 1, 'laterale.png'),
(35, 2, 'Elevation frontale', 60, 1, 1, 'frontale.png'),
(36, 5, 'Dips', 60, 1, 1, 'dips.png'),
(37, 5, 'Pompe épaule', 60, 1, 1, 'pompeEpaule.png'),
(38, 5, 'Crunch elastique', 60, 1, 0, 'CrunchGenoux.png'),
(39, 3, 'Twist elastique', 60, 1, 0, 'TwistOblique.png'),
(40, 5, 'Traction une main', 60, 1, 0, 'TractionUneMain.png'),
(41, 5, 'Shrug', 60, 1, 0, 'Shrug.png'),
(42, 5, 'Ecarter', 60, 1, 0, 'Ecarter.png'),
(43, 5, 'Presse', 60, 1, 0, 'Presse.png'),
(44, 5, 'Donkey kick', 60, 1, 0, 'DonkeyKick.png'),
(45, 5, 'Pull over', 60, 1, 0, 'pullOver.png'),
(46, 5, 'Tirage horizontal', 60, 1, 0, 'TirageHoritontal.png'),
(47, 5, 'Mollet amplitude', 60, 1, 0, 'MolletAmplitude.png'),
(48, 5, 'Pont', 60, 1, 1, 'pont.png');

-- --------------------------------------------------------

--
-- Structure de la table `infocorps`
--

CREATE TABLE `infocorps` (
  `Date` date NOT NULL,
  `kg` int(11) NOT NULL,
  `pseudo` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `infocorps`
--

INSERT INTO `infocorps` (`Date`, `kg`, `pseudo`) VALUES
('2021-12-19', 85, 'Line'),
('2021-12-03', 85, 'Line'),
('2021-11-26', 75, 'Line'),
('2021-12-31', 890, ''),
('2022-01-08', 85, 'Line');

-- --------------------------------------------------------

--
-- Structure de la table `montre`
--

CREATE TABLE `montre` (
  `date` date NOT NULL,
  `energie` int(11) NOT NULL,
  `tempsSeance` int(11) NOT NULL,
  `tempsSommeil` int(11) NOT NULL,
  `CardMax` int(11) NOT NULL,
  `CardMin` int(11) NOT NULL,
  `CardMoyenne` int(11) NOT NULL,
  `NbPas` int(11) NOT NULL,
  `pseudo` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `montre`
--

INSERT INTO `montre` (`date`, `energie`, `tempsSeance`, `tempsSommeil`, `CardMax`, `CardMin`, `CardMoyenne`, `NbPas`, `pseudo`) VALUES
('2021-12-07', 961, 129, 413, 150, 49, 81, 20049, 'Line'),
('2021-12-09', 890, 137, 397, 158, 47, 78, 14944, 'Line'),
('2021-12-14', 1091, 142, 0, 0, 0, 0, 0, 'Line');

-- --------------------------------------------------------

--
-- Structure de la table `muscexo`
--

CREATE TABLE `muscexo` (
  `NumMuscle` int(11) NOT NULL,
  `NumExercice` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `muscexo`
--

INSERT INTO `muscexo` (`NumMuscle`, `NumExercice`) VALUES
(1, 9),
(1, 22),
(1, 24),
(1, 32),
(1, 34),
(1, 35),
(1, 36),
(1, 37),
(1, 45),
(2, 28),
(2, 41),
(3, 19),
(3, 31),
(3, 40),
(3, 45),
(3, 46),
(4, 16),
(4, 17),
(4, 19),
(4, 31),
(4, 40),
(5, 9),
(5, 20),
(5, 21),
(5, 22),
(5, 23),
(5, 24),
(5, 32),
(5, 36),
(5, 42),
(5, 45),
(6, 9),
(6, 16),
(7, 22),
(7, 23),
(7, 24),
(7, 32),
(7, 36),
(7, 42),
(7, 45),
(8, 15),
(8, 33),
(8, 38),
(8, 39),
(9, 25),
(9, 26),
(9, 27),
(9, 28),
(9, 43),
(9, 48),
(10, 26),
(10, 27),
(10, 28),
(10, 43),
(10, 48),
(11, 26),
(11, 27),
(11, 28),
(11, 43),
(11, 48),
(12, 29),
(12, 30),
(12, 43),
(12, 47);

-- --------------------------------------------------------

--
-- Structure de la table `muscle`
--

CREATE TABLE `muscle` (
  `NumMuscle` int(11) NOT NULL,
  `LibelleMuscle` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `muscle`
--

INSERT INTO `muscle` (`NumMuscle`, `LibelleMuscle`) VALUES
(1, 'Epaule'),
(2, 'Trapeze'),
(3, 'Grand dorsal'),
(4, 'Biceps'),
(5, 'Triceps'),
(6, 'Avant bras'),
(7, 'Pectoraux'),
(8, 'Abdominaux'),
(9, 'Fessier'),
(10, 'Quadriceps'),
(11, 'Ischio jambier'),
(12, 'Mollet');

-- --------------------------------------------------------

--
-- Structure de la table `ordrecategorie`
--

CREATE TABLE `ordrecategorie` (
  `NumEntrainement` int(11) NOT NULL,
  `NumCategorie` int(11) NOT NULL,
  `NumExercice` int(11) NOT NULL,
  `Ordre` int(11) NOT NULL,
  `pseudo` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `ordrecategorie`
--

INSERT INTO `ordrecategorie` (`NumEntrainement`, `NumCategorie`, `NumExercice`, `Ordre`, `pseudo`) VALUES
(4, 1, 7, 7, 'Line'),
(4, 1, 8, 8, 'Line'),
(5, 4, 46, 4, 'Line'),
(5, 7, 8, 8, 'Line'),
(5, 7, 7, 7, 'Line'),
(5, 6, 43, 5, 'Line'),
(5, 6, 28, 4, 'Line'),
(5, 6, 26, 3, 'Line'),
(5, 5, 20, 4, 'Line'),
(5, 3, 39, 2, 'Line'),
(5, 3, 38, 1, 'Line'),
(5, 1, 8, 8, 'Line'),
(5, 1, 7, 7, 'Line'),
(5, 1, 6, 6, 'Line'),
(5, 1, 5, 5, 'Line'),
(5, 1, 4, 4, 'Line'),
(5, 1, 3, 3, 'Line'),
(5, 1, 2, 2, 'Line'),
(5, 1, 1, 1, 'Line'),
(2, 6, 7, 7, 'Line'),
(2, 6, 8, 8, 'Line'),
(2, 6, 4, 4, 'Line'),
(2, 6, 5, 5, 'Line'),
(2, 5, 25, 2, 'Line'),
(2, 3, 31, 3, 'Line'),
(2, 2, 11, 4, 'Line'),
(2, 1, 9, 9, 'Line'),
(1, 6, 8, 8, 'Line'),
(1, 6, 7, 7, 'Line'),
(1, 6, 6, 6, 'Line'),
(1, 6, 5, 5, 'Line'),
(1, 6, 4, 4, 'Line'),
(1, 6, 3, 3, 'Line'),
(1, 4, 20, 3, 'Line'),
(1, 1, 9, 9, 'Line'),
(1, 1, 8, 8, 'Line'),
(1, 1, 7, 7, 'Line'),
(1, 1, 6, 6, 'Line'),
(1, 1, 5, 5, 'Line'),
(4, 1, 3, 3, 'Line'),
(5, 4, 17, 1, 'Line'),
(5, 7, 6, 6, 'Line'),
(5, 7, 5, 5, 'Line'),
(5, 4, 40, 3, 'Line'),
(5, 4, 16, 2, 'Line'),
(5, 2, 41, 1, 'Line'),
(2, 6, 6, 6, 'Line'),
(2, 6, 3, 3, 'Line'),
(2, 6, 2, 2, 'Line'),
(2, 6, 1, 1, 'Line'),
(2, 5, 28, 3, 'Line'),
(2, 5, 47, 1, 'Line'),
(2, 4, 45, 2, 'Line'),
(2, 3, 16, 1, 'Line'),
(2, 2, 10, 2, 'Line'),
(2, 1, 8, 8, 'Line'),
(4, 1, 9, 9, 'Line'),
(2, 1, 7, 7, 'Line'),
(2, 1, 6, 6, 'Line'),
(2, 1, 5, 5, 'Line'),
(2, 1, 4, 4, 'Line'),
(2, 1, 3, 3, 'Line'),
(1, 5, 25, 2, 'Line'),
(4, 2, 14, 2, 'Line'),
(4, 5, 28, 4, 'Line'),
(1, 1, 4, 4, 'Line'),
(1, 1, 3, 3, 'Line'),
(1, 1, 2, 2, 'Line'),
(3, 1, 1, 1, 'Joe'),
(5, 5, 45, 2, 'Line'),
(2, 1, 2, 2, 'Line'),
(2, 1, 1, 1, 'Line'),
(1, 2, 14, 2, 'Line'),
(1, 2, 15, 1, 'Line'),
(1, 6, 2, 2, 'Line'),
(1, 6, 1, 1, 'Line'),
(4, 1, 6, 6, 'Line'),
(4, 1, 5, 5, 'Line'),
(4, 1, 4, 4, 'Line'),
(4, 2, 15, 1, 'Line'),
(4, 3, 19, 3, 'Line'),
(4, 3, 17, 2, 'Line'),
(5, 7, 4, 4, 'Line'),
(5, 7, 3, 3, 'Line'),
(5, 7, 2, 2, 'Line'),
(5, 7, 1, 1, 'Line'),
(4, 5, 26, 3, 'Line'),
(4, 5, 25, 2, 'Line'),
(4, 5, 29, 1, 'Line'),
(4, 6, 7, 7, 'Line'),
(4, 6, 6, 6, 'Line'),
(4, 6, 5, 5, 'Line'),
(4, 6, 4, 4, 'Line'),
(4, 6, 3, 3, 'Line'),
(4, 6, 2, 2, 'Line'),
(4, 6, 1, 1, 'Line'),
(4, 6, 8, 8, 'Line'),
(1, 1, 1, 1, 'Line'),
(4, 4, 37, 3, 'Line'),
(4, 4, 32, 2, 'Line'),
(4, 1, 2, 2, 'Line'),
(4, 1, 1, 1, 'Line'),
(4, 3, 31, 1, 'Line'),
(4, 4, 24, 1, 'Line'),
(5, 5, 22, 3, 'Line'),
(5, 5, 23, 1, 'Line'),
(5, 6, 29, 2, 'Line'),
(5, 6, 25, 1, 'Line'),
(1, 3, 19, 3, 'Line'),
(1, 3, 16, 2, 'Line'),
(1, 3, 17, 1, 'Line'),
(1, 3, 46, 4, 'Line'),
(1, 4, 45, 2, 'Line'),
(1, 4, 23, 1, 'Line'),
(1, 4, 22, 4, 'Line'),
(2, 4, 22, 4, 'Line'),
(2, 4, 37, 3, 'Line'),
(2, 4, 23, 1, 'Line'),
(2, 3, 18, 2, 'Line'),
(2, 3, 46, 4, 'Line'),
(2, 2, 10, 3, 'Line'),
(2, 2, 15, 1, 'Line'),
(1, 5, 28, 3, 'Line'),
(1, 5, 47, 1, 'Line');

-- --------------------------------------------------------

--
-- Structure de la table `partageentrainement`
--

CREATE TABLE `partageentrainement` (
  `NumEntrainement` int(11) NOT NULL,
  `pseudo` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `partageentrainement`
--

INSERT INTO `partageentrainement` (`NumEntrainement`, `pseudo`) VALUES
(4, 'Line'),
(2, 'Line'),
(1, 'Line'),
(3, 'Line'),
(5, 'Line');

-- --------------------------------------------------------

--
-- Structure de la table `perfdate`
--

CREATE TABLE `perfdate` (
  `NumExercice` int(11) NOT NULL,
  `NbRep` int(11) NOT NULL,
  `PoidsHaltere` int(11) NOT NULL,
  `PoidsLest` int(11) NOT NULL DEFAULT '0',
  `PoidsElastique` int(11) NOT NULL DEFAULT '0',
  `Ressentie` text NOT NULL,
  `Texte` text NOT NULL,
  `Date` date NOT NULL,
  `pseudo` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `perfdate`
--

INSERT INTO `perfdate` (`NumExercice`, `NbRep`, `PoidsHaltere`, `PoidsLest`, `PoidsElastique`, `Ressentie`, `Texte`, `Date`, `pseudo`) VALUES
(47, 20, 0, 8, 85, 'MOLLET', 'NON RENSEIGNER', '2022-02-07', 'Line'),
(22, 14, 0, 0, 45, '', 'NON RENSEIGNER', '2022-02-07', 'Line'),
(20, 8, 0, 0, 45, '', 'NON RENSEIGNER', '2022-02-07', 'Line'),
(45, 12, 0, 0, 45, '', 'NON RENSEIGNER', '2022-02-07', 'Line'),
(23, 19, 40, 0, 45, '', 'NON RENSEIGNER', '2022-02-07', 'Line'),
(46, 15, 0, 0, 45, '', 'NON RENSEIGNER', '2022-02-07', 'Line'),
(17, 14, 0, 0, 60, '', 'NON RENSEIGNER', '2022-02-07', 'Line'),
(9, 64, 40, 8, 0, 'FATIGUE', 'NON RENSEIGNER', '2022-02-14', 'Line'),
(17, 15, 0, 0, 60, '', 'NON RENSEIGNER', '2022-02-14', 'Line'),
(46, 18, 0, 0, 45, '', 'NON RENSEIGNER', '2022-02-14', 'Line'),
(23, 12, 40, 0, 60, 'difficulte extreme', 'NON RENSEIGNER', '2022-02-14', 'Line'),
(45, 15, 0, 0, 35, '', 'NON RENSEIGNER', '2022-02-05', 'Line'),
(19, 8, 0, 8, 0, '', 'NON RENSEIGNER', '2022-02-05', 'Line'),
(9, 62, 40, 8, 0, 'trapeze', 'NON RENSEIGNER', '2022-02-05', 'Line'),
(25, 62, 0, 0, 22, '', 'NON RENSEIGNER', '2022-02-03', 'Line'),
(45, 14, 0, 0, 45, '', 'NON RENSEIGNER', '2022-02-14', 'Line'),
(20, 9, 0, 0, 45, '', 'NON RENSEIGNER', '2022-02-14', 'Line'),
(22, 15, 0, 0, 45, '', 'NON RENSEIGNER', '2022-02-14', 'Line'),
(37, 17, 0, 8, 0, '', 'NON RENSEIGNER', '2022-02-03', 'Line'),
(28, 11, 40, 7, 80, '', 'NON RENSEIGNER', '2022-01-31', 'Line'),
(25, 64, 0, 0, 22, '', 'NON RENSEIGNER', '2022-02-14', 'Line'),
(47, 17, 0, 8, 95, '', 'NON RENSEIGNER', '2022-02-14', 'Line'),
(45, 12, 0, 0, 35, 'PECS', 'NON RENSEIGNER', '2022-01-31', 'Line'),
(15, 25, 0, 7, 0, 'rien', 'NON RENSEIGNER', '2022-01-24', 'Line'),
(17, 20, 0, 0, 60, 'r', 'r', '2022-01-24', 'Line\r\n'),
(28, 22, 40, 7, 60, '', 'NON RENSEIGNER', '2022-01-24', 'Line'),
(16, 12, 0, 0, 45, '', 'NON RENSEIGNER', '2022-02-03', 'Line');

-- --------------------------------------------------------

--
-- Structure de la table `token`
--

CREATE TABLE `token` (
  `pseudo` text NOT NULL,
  `token` text NOT NULL,
  `date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `token`
--

INSERT INTO `token` (`pseudo`, `token`, `date`) VALUES
('Line', '9GJzRwlZrvDrmLOLBRAhCTcRntmPlGh3w6GQkRM4Mwi4jbsGUsYf1q4DEFt9einFLTvvGz5wZUQ48ZZZ5rfBjjPMNfrQZilES4cxU', '2021-12-21'),
('Line', 'PgejtUoybh6khTrSCGZUx7RDTbEM1lrzKzQIsjVqXyirBM3YeVMJctAWlo2k1af63KOYNBPb5ISqhw3Wd2XreHF8buNKoRrvJNa7w', '2021-12-21'),
('Line', 'NCJPhlaqMA1u0EN8borW29qZMMJU8CNKivD91NFavjTpsqMY8YhrdhSVWcx015IMFMoQCB3h5qDHNACbWVZkgMceY0duMWvbVq3U6', '2021-12-21'),
('Line', '2UUO9ZGPeC8q6KTj7P1I8Q7lthir057H2IIlsaE5zU2afTsiOA0G7Yh3vvnCPaT7qpTK8e0ei4jNLUp9SdnwtXPDVBQG271paZs1b', '2021-12-21'),
('Line', 'riwQlL1yEjZskw7SQuDFaNg9MyecDmd9chuPsWJBSpbiphxgxF3ld9pSWQQIEj5dPEkbstj0YReumqQ06eko9TqYYulCyDOElo2Vj', '2021-12-21'),
('Line', 'oLNWHa4cV08yauOXZjrTwISkkqtIwD23G5WNVZ2UO3DRtvCDt4iGVYwYoUEY16wFliuwvFmu4Yw39qMbkIwlH5xuQgd7Sroaomo7t', '2021-12-21'),
('Line', 'lBJJ88gIaR0bMf4lOf2VCl193vBJqbSTCnrlXwnjhBivV6h9LXVY7FkbQb5vhYh8g1vP8MSMLdXItPRQ6xbT0R051JW8vD3ghxXbH', '2021-12-21'),
('Line', 'zwWHY53972wpD6HXzvrKyW4gFDrsvjTOacghe0VlOXHYuKVClCsh0iDoxYiWyoNp8LYJSNbpRJfoIgw9vCQFPwzoMcxjYl5Stc34S', '2021-12-21'),
('Line', '90AtpgqpANRRUrRp5xT9kWVGnZp6rxlYeUbrYYT3o2WVGZiDB8qjkljvCWqlEMIobcEMp3d33FSmlUBfZ6QPd6AHIfjXKoXb0R0uJ', '2021-12-22'),
('Line', 'rk2gTrtVUuBr5dJiwPJtN3Xq16d7NHS2b3M8OTgTKqbgBoRKsZahUWqk3tuTujHqjETS6dqKXf8Ztrm3L1XXoIg7sJ8xzNSFN7nuL', '2021-12-22'),
('Line', '02NfEP94dKUO3faH1jwqqo5f9uqRw2Etn2lP3VB8qH27OOIY4efrwrJK2oKAXyoc6UghQUr40xyhWgE8u2ml0lL7j9rcLVvMdEyB0', '2021-12-22'),
('Line', 'nuaJ2bmJoaZ3jpFr8ls4HZZGlLkvUG5fKbl8HfIS7kgGQqBicZPU3YxgKSNz7DeyvKUpKarTdnVbJkW1EuzDNQrIxQDvHtJIDcQzb', '2021-12-22'),
('Line', 'McxjYl5Stc34StOmioaHjEuz1vCW1DThpi9yLbKebvwhg1Oa6UtSiVQRVfL5BCz2og8FVSMsgHlm1rbSik8VE3y1cSh7ytDFL6uFt', '2021-12-22'),
('Line', 'D3aw1PYoiLshUWO2PYN0xXA0YsVqEB24uYCj0FUY8gCplSYsD4GtrYXhKaxf1JDbegXtRSJVQ9FUFb0gjyrjendVoe1qhe6GRW90A', '2021-12-23'),
('Line', 'L3T5HS1ALyD70jxD1Q5DWp84kH0ohWzBoR89LFA0Z4eE9iV2Q52DbDnqKEiSCnEWpwL6cjvjAsc4GbHj3clwNIZFxtXekH69N4LU0', '2021-12-23'),
('Line', 'Gr78RCGBcLDywRxLblwp1dbenUAr6qkKwdwovgL4o1710tdXI475lNr9f6glgZboKTiwxNdrX9ZnSXf2CF5E3f4Wvbj7PppUlqswV', '2021-12-24'),
('Line', 'XmZJfimsaru7TEnjbfu9d5MdKvIAYmhSCZWaUdF3yqUELqEwhzmMjH10za4ihOugaZLYrwQ2OLcywzN5gf7LhG8ahciotEz1Ams9Q', '2021-12-25'),
('Line', 'LQtxqw9AnmN2QbosxlnWGFJ50xWZIKXexGfVFaNFRy3wjF07KS6wn0klVp8FCVv5aUVINbj7d7boExuaOMHuWIMYJFdJptWkGvsRN', '2021-12-25'),
('Line', 'cToXumP95P28kK8737IRCoQxRx9T71I7fP7YAotEYImRLgSQMZDjonGtrnF3ftEhFCeR3jv1fu3tzE0rTJVDydUho5y6KNXjtiHCU', '2021-12-25'),
('Line', '6UgT88XLUvUolAP5WuYJFO1DZDdERyg7LGoUFAjk2mffQDU0ysxq8rOS3HZchNMIiPoi3pxh2Csuc2Rh1NYvssuvZ7E7AoaHImg4k', '2021-12-25'),
('Line', 'gPIFvGFQ277aG7FkN9pAcaWDfFlGNBeuaqGed8iDibaWexTQoGyAAzLRbFAU1XErrU1FitjjV8BBaQuem65smQXYvyd0Dcrg6fJYL', '2021-12-26'),
('Line', 'tdgFkuc9d6nvY1ptWIohXaUCmP3J1Gpjfb6BUjHjlxjFoOwmpDpEdWBebdaj7qIDp2jpS1AmQRCHcvZ8fqOTRAFImtFMC2nQWLU6c', '2021-12-26'),
('Line', 'p7s1tvHnZdvZwXcjcYCjBX8tPaALshiDAx85PEqygP10tOgWzOZj9xyAidNJAz3d9Ob0yEwAUkUUNyHskxJb4Zky89ny6KbE5YBOF', '2021-12-27'),
('Line', 'GwgKt5NCk7vRRjKW8TlPLAEZPBvpWFgybZKn8iklVOQr7eC8ONvnCeRFBJwWo1PG3kCRbnfWTmyUK1ScSA4OQKscLJUkdfLGiyReB', '2021-12-27'),
('Line', 'usMEmOePkakDm7NoVMPXZI9F01ZmYj4olGAB4HhkEtmq2ByeIb4BDMDRgwsQAZgV4ghWFXcdQagBBscsnXcC9eZqooNI51lQFePD7', '2021-12-28'),
('Line', 'ElHoTsZRkEAkxDPfDCyCdm7Tl2m2EoCwdCKkCt5TY9tdRmgLnlhu8OTSbYWSayKY9Ma7JmyO0wKZyY49vWoeq83IpMTA3BfisOYNc', '2021-12-29'),
('Line', 'ZTWqWmHZAng3wIY4QyF28CHou9U8vQEIiVK6q7yMZDUHBcakk1aENPf75QfIMLwUYPVFgLMrLLVd2yJscm18QU9J2oXbpyMY2Ct5v', '2021-12-29'),
('Line', 'pLoDDsgp0pTQ5kArZteajw8u8I9m3LCgbTpa5OPxRKKl8pv3X2VDWjnycuHMihdNkTNyU2Mx7XZHxmMwit0XXZ0uC9C5TFcdRLzP6', '2021-12-29'),
('Line', 'IMLwUYPVFgLMrLLVd2yJscm18QU9J2oXbpyMY2Ct5vgnYULkCRMFtsAgvgRrcnP2wqepVsgoo6FlorD5T4TZl4FSK3G5y69uJOMpK', '2021-12-31'),
('Line', 'DNPQqjlWCJ7Dji0S7Jma6e1rTwkbyP7mGSKroR3pfwnHn5zjlfXHgepPIKgbN3mJ6P1VJi8Jgc0EOJuCWDW7M6b6URA4p8YYTEGgr', '2022-01-01'),
('Line', 'cNWoCwBkwOVz7xSJ92UUO9ZGPeC8q6KTj7P1I8Q7lthir057H2IIlsaE5zU2afTsiOA0G7Yh3vvnCPaT7qpTK8e0ei4jNLUp9Sdnw', '2022-01-01'),
('Line', 't5vgnYULkCRMFtsAgvgRrcnP2wqepVsgoo6FlorD5T4TZl4FSK3G5y69uJOMpKgNHz5VGGlne2DSG64DRRdo8MbkkOzcMrscnDr4p', '2022-01-02'),
('Line', 'VVTAKEZVm1x9YSxQkyq6DVcxCjjdtzJKW1WefxTf5s3THBpLMlpWzv23MrL9DZxRQvQgCOEWHgq0hI936vgansKWPW4sFNdlBlDFR', '2022-01-03'),
('Line', 'sj1bsGvKdLIj2ZK4NkcKPg9zYLcfzirZtPtx1Pn64fLoWAIDvNPx4lclwcqLaQAZSeiLYPCjjCble334A8QdHhD0rv198f7RDvuSh', '2022-01-03'),
('Line', 'rQiQTftywau1yrkPGrq58ZMoDqROoBCX8SwW54zjWxbcX7nbOaAnKvOluuubeYBvIhDo9hwsfiLLeajVPgD1foHFdVZVXItqa4Be5', '2022-01-03'),
('Line', '8cZKayQkX8S8ejzgdUTiBhilDgLY2dLj0YgWgRJW3K7V3YVYwm6G9h79azWXiz3dK6pvfyuW1Jf5L093IcbrzFOkAf0jrhdunDrs7', '2022-01-04'),
('Line', 'JDTTjOSKl23HGf1qGVSaa2cEt455sX8btcramKBLr4IbA9l97rCTTU76g2V13NEmBDnkMyIEUZJzQU2LWOJu0EpqpT8P0vxo6XGmA', '2022-01-06'),
('Line', 'qLL8Ouz7f74eXug4DXCJwk5NjZ9ngLM23ZrUWw5zBHc6imL7IRdH42yq7feq2jdhzAY4WUuoQDdlvB7wF9H2w7TrMRaRHevSYynAO', '2022-01-07'),
('Line', 'JIDcQzbYyMGhWy06DDsSHeUAK3GHQkEbCL8w9BYE1xx4lOEKH7E8cHocpfeqr0ZLSG0IPv9dSbLJ7VFg9tdg42gGrk81pzGewugMT', '2022-01-08'),
('Line', 'WeDEmwTRcze6FfDVvSzsUk0gBUpsPtKChouRatBKf4ypH3jpgJmR9XEl56FXiYmitVdrRNb1aXK5BeSgUX1DhZbMsFNPDPRkyPOpq', '2022-01-08'),
('Line', 'r7eC8ONvnCeRFBJwWo1PG3kCRbnfWTmyUK1ScSA4OQKscLJUkdfLGiyReBkwqeNDeLHv9jeZ7r8rChBGBpm5zUDtto9bLW75r9fvX', '2022-01-08'),
('Line', 'qoMTblPKZlLkUBsAyRdZ1iUxUFSEiaXlMxv4sYlMVcPXhsOz6qD6um7u2XDeRs0hvyB67tfFfWhs1ayr1Sp4kiHky8LFMBr4Cr408', '2022-01-08'),
('Line', 'vEEXdO9oMiuqyzMhnzBGBO4R4dKv7hKRAYFDQLA2HB6OwYj99QONUGGWGsxkMDsa2b3bQAoz0M44RgdUiZnMBrGUFzI2ORymShOBd', '2022-01-08'),
('Line', 'mEyUlINt4M8cB2o3xdUuZxyuxIFwhX4yO072d4FY6R2NyB5va1ay2j6VLeg3qXsWDf33shUkwOkhT2bQbGNvtY2dnCetXPedPlnV5', '2022-01-09'),
('Line', 'SEiaXlMxv4sYlMVcPXhsOz6qD6um7u2XDeRs0hvyB67tfFfWhs1ayr1Sp4kiHky8LFMBr4Cr408QvrXy5Q9LFbjdzVx7E2rbgZ5De', '2022-01-09'),
('Line', 'JQHWLd3sYX49IxQeOVYqCAyWYv9ve9Tkdsm8iWD9jxk4AJx9ZtP4Pfk4Z2BRNhLG5XpddxBI1ZYSQNAVxU4AqNt4nqq6Jh0TkkOau', '2022-01-10'),
('Line', 'ZxtJ1AscFYpc0W9HDd3aDZWyCZ9mEsyxm5tyP6LoEeKuUHiQccJVDXVGMHbAKEnC8vQf1wqr0ntEbjOS93OyZNhFjhBGdHAAgOBPz', '2022-01-12'),
('Line', 'tcK7C6HySJWrsTqm4YCpXMvcPFxMUuHNTzrj1MLU0r6I4prjV2fMO8uJp4DfXHEVbk1RiPGE1x8nzjlDFtKxwSmERRC5ThurmssNs', '2022-01-12'),
('Line', 'NQKFNdJj78YYuXUM8vxiK9kEzIfpjyKFcwO1VVTAKEZVm1x9YSxQkyq6DVcxCjjdtzJKW1WefxTf5s3THBpLMlpWzv23MrL9DZxRQ', '2022-01-12'),
('Line', 'jpS1AmQRCHcvZ8fqOTRAFImtFMC2nQWLU6cCQhJ3iBn3QMt5A1S674WBx8txqVRmSFU4u4Z7mnVt5h4CK1hvWiSBMlITPS8Qd6Zpu', '2022-01-15'),
('Line', '1u0EN8borW29qZMMJU8CNKivD91NFavjTpsqMY8YhrdhSVWcx015IMFMoQCB3h5qDHNACbWVZkgMceY0duMWvbVq3U6NjMyVfmZ7l', '2022-01-15'),
('Line', 'XTXfP2d4ggkmJHwXcUvc80vVuAeuLJUJU1gZoAv7cZlsMl1Q6eeDDLdFmvGhKzQjKxq7QwEy06eVGno7SWQs1SOM6N0qBMEgsqtCa', '2022-01-15'),
('Line', 'B4N2QMGG22gT2M9pbuork8CHNcVprCSiCTBz9XFWokaEbVIoSfopjgNpPq0BhHEIZAMYP1157urgHWFfWSLfGfkYewtFtFM0K9lfS', '2022-01-15'),
('Line', 'mUADHSl8j9eBjV70iWlNloKY31FZw3WPkbWVADuhT8VmjT67sDn1rAz4Or2GHsCSGjF5Sf0jQZZZGJt60dM8TEM1XKNggJFOqkL8w', '2022-01-17'),
('Line', 'KTcaIquqsdYVFz6JAmRsUVHcT5Bwde2y8aYRkfSy2kIdZJXXojzlXq1vVTh0Z4PWnOCVOr82vOkScgGx5E9BSidbP4QRCiuJvP9na', '2022-01-19'),
('Line', 'vwbwvGYNitdX7MTAETtN9HV9jwJMmdQf17JFv4mCxqdck0g0BbX8AMgaZ9Gd199Rp58cnQDOEJ6OqCvNrQiQTftywau1yrkPGrq58', '2022-01-21'),
('Line', 'wFKByfjti6kGAdnVM1yrIxsWJcaDGZifTmW0eiFC1gBi7ekMQFVh5wZv9iDGTWrxEVuhhepD7ifN08EwiaF0OoUXVhtDtMWIMnqrH', '2022-01-24'),
('Line', 'CaxlnxZTfMUui5758cZ8RjlD3aw1PYoiLshUWO2PYN0xXA0YsVqEB24uYCj0FUY8gCplSYsD4GtrYXhKaxf1JDbegXtRSJVQ9FUFb', '2022-01-27'),
('Line', '0gjyrjendVoe1qhe6GRW90AtpgqpANRRUrRp5xT9kWVGnZp6rxlYeUbrYYT3o2WVGZiDB8qjkljvCWqlEMIobcEMp3d33FSmlUBfZ', '2022-01-27'),
('Line', 'EHa5OeeDf3ra3oDDQYauIZTJeb7OvLIH8s1SctSijxDqyR8fwaIdiGdju6Z0bGTgZ6fxZBTOLTcyqcZJyfCOgfVM8Uf4fsrGdCQ48', '2022-01-27'),
('Line', '7ws9xfD1RHVaUPXh37NB7w3QtwOeV5GsQGJM3gATVki0hOvRtdgFkuc9d6nvY1ptWIohXaUCmP3J1Gpjfb6BUjHjlxjFoOwmpDpEd', '2022-01-30'),
('Line', 'yNcemHZZ52xPO1IJ9lRaafN6usS0aaWQQ7m5zwWHY53972wpD6HXzvrKyW4gFDrsvjTOacghe0VlOXHYuKVClCsh0iDoxYiWyoNp8', '2022-01-30'),
('Line', 'mbPmbPLTBgcHiQBTvpV3XkFiRpMcV1KQoZvQXFyiQUQMM2RoYUyJaRoSyKnsQTWwia3HATd4YVmd8BZgkL2LfL0Q6rP5E90A4IuV6', '2022-01-31'),
('Line', 'K46hs7V4zec13ZDvowtmxppUXIG1C5Z10zzL4M7BiOSmEgyoAcnw5g38CvO28wlA8rUDzPcvTMr46TmDEga5vuzJ9ENqxlAx8G8SV', '2022-02-02'),
('Line', '4WOwhgpvWBdzUWOqxKhjDZeUz8Ksc9qGPwmNkb9w2DS4OQ8aYf21nR9mm7AoMZWRXXiXLZfpwyTr5CPMMD9CuBrGwXNdJHPUshBZy', '2022-02-03'),
('Line', 'ZiDZQcNDrm9vx59HkgMNxcvUnKiBAfB0nzpHr1bL2tTNRf0U8duGAHPdpxY5l6opCc3LVdrgvXvt3MJvPx5Wvz1TjIwWZj3bKezdh', '2022-02-05'),
('Line', 'Mz7QO0v8HksnfxAiP5X6gXavUAlKCY2wIAn43mV5YONOkSAYs2nKcfMTT0RCofeD2sZ9FBIVDaw8M5YvsRchuqLaeiLmxoOCJdZ7E', '2022-02-05'),
('Line', 'JTCFoBjCaJVPynGau7iXs2Z3qLtNQmY1Iqc5u4nP8SeA7VYdpQj3uHuWj5cem6GLAlERsUjpYnoIzR7DdWcwpIRd5MO2JdhSkDY1j', '2022-02-07'),
('Line', '4jbsGUsYf1q4DEFt9einFLTvvGz5wZUQ48ZZZ5rfBjjPMNfrQZilES4cxUFhm4FgsPboE8NoktBriObjUCFb0RBMX07lz2NzcoJGI', '2022-02-13'),
('Line', 'wit0XXZ0uC9C5TFcdRLzP695qJ3BWlcrS0Mtalx0jrGVgSWxvLvIYG8MbJ1A3vTt66Xig6Xo0C5Bke4gF28e0CZQO6RW33tTcz1vd', '2022-02-13'),
('Line', 'eusMEmOePkakDm7NoVMPXZI9F01ZmYj4olGAB4HhkEtmq2ByeIb4BDMDRgwsQAZgV4ghWFXcdQagBBscsnXcC9eZqooNI51lQFePD', '2022-02-14');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `mail` text NOT NULL,
  `pseudo` text NOT NULL,
  `mdpHASH` text NOT NULL,
  `aMontre` tinyint(1) NOT NULL DEFAULT '0',
  `isValide` int(11) NOT NULL,
  `nbTentative` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`mail`, `pseudo`, `mdpHASH`, `aMontre`, `isValide`, `nbTentative`) VALUES
('p5mq1TBwlYbXGln7aahxanKFHLePiva1QI/FgK7+VeE=', 'Line', '3c7de7d4651852d5cdcd85494fe65f9e', 1, 1, 0);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `aliment`
--
ALTER TABLE `aliment`
  ADD PRIMARY KEY (`IdAliment`);

--
-- Index pour la table `categoriealiment`
--
ALTER TABLE `categoriealiment`
  ADD PRIMARY KEY (`IdCategorieA`);

--
-- Index pour la table `entrainement`
--
ALTER TABLE `entrainement`
  ADD PRIMARY KEY (`NumEntrainement`);

--
-- Index pour la table `exercice`
--
ALTER TABLE `exercice`
  ADD PRIMARY KEY (`NumExercice`);

--
-- Index pour la table `muscexo`
--
ALTER TABLE `muscexo`
  ADD PRIMARY KEY (`NumMuscle`,`NumExercice`);

--
-- Index pour la table `muscle`
--
ALTER TABLE `muscle`
  ADD PRIMARY KEY (`NumMuscle`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
