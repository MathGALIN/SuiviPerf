<?php
echo "
<script>
	document.location = 'UTILISATEUR/connexion.php';
</script>
";
?>