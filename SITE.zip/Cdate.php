<?php
class Cdate
{
	public $Jour;
	public $Mois;
	public $An;
	public $type=0;
	
	
	public $Pseudo;
	
	//Construit notre objet
	public function __construct($Date="", $Pseudo="")
	{
		//Si pas de date renseigner donne la date du jour
		if ($Date == "")
		{
			$this->An = date("Y");
			$this->Mois = date("m");
			$this->Jour = date("d");
		}
		
		//Utilise la date des paramètres
		if ($Date != "")
		{
			//Réparer la fonction pour insérer les dates
			$this->An = $Date[0].$Date[1].$Date[2].$Date[3];
			$this->Mois = $Date[5] . $Date[6];
			$this->Jour   = $Date[8] . $Date[9];
		}
		
		$this->Pseudo = $Pseudo;
	}
	
	
	

	public function GetDate()
	{
		return $this->An."-".$this->Mois."-".$this->Jour;
	}
	
	public function GetLibelleMois()
	{
		$mois = $this->Mois;
		
		if ($mois == "01" || $mois == "1")
		{
			return "Janvier";
		}
		
		if ($mois == "02" || $mois == "2")
		{
			return "Février";
		}

		if ($mois == "03" || $mois == "3")
		{
			return "Mars";
		}

		if ($mois == "04" || $mois == "4")
		{
			return "Avril";
		}

		if ($mois == "05" || $mois == "5")
		{
			return "Mai";
		}

		if ($mois == "06" || $mois == "6")
		{
			return "Juin";
		}
		
		if ($mois == "07" || $mois == "7")
		{
			return "Juillet";
		}

		if ($mois == "08" || $mois == "8")
		{
			return "Aout";
		}

		if ($mois == "09" || $mois == "9")
		{
			return "Septembre";
		}

		if ($mois == "10")
		{
			return "Octobre";
		}

		if ($mois == "11")
		{
			return "Novembre";
		}
		
		if ($mois == "12")
		{
			return "Décembre";
		}
	}
	
	public function AfficheJourCalendrier()
	{
		$la_date = $this->Jour;
		$IsToday = $this->IsToday();
		
		//Si le jour n'est pas un entraînement
		if ($this->type == 0 && $IsToday == false)
		{
			echo " 
			<card class='card' border-2' style='width: 6.6rem; height: 5rem;'>			
			  <div class='card-body'>
				<h4 align='center' class='card-text' style='margin-top:0.5rem;'> $la_date</h4>
			  </div>
			</card>";
		}
		
		
		//Si il s'agit de la journée d'aujourdhui
		if ($IsToday)
		{
			echo " 
			<card class='card' border-2' style='width: 6.6rem; height: 5rem; background:orange;'>			
			  <div class='card-body'>
				<h4 align='center' class='card-text' style='margin-top:0.5rem;'>$la_date</h4>
			  </div>
			</card>";	
		}

		//Si il ne s agit pas d un entrainement
		if ($this->type == 1 && $IsToday == false)
		{
	    echo "
	    <card class='card border-2' style='width: 6.6rem; height: 5rem; background:cyan;'>
	      <div class='card-body'>
	        <h4 align='center' class='card-text' style='margin-top:0.5rem;'>$la_date</h4>
	      </div>
	    </card>";
	}
		 
	}
	
	public function IsToday()
	{
			$An = date("Y");
			$Mois = date("m");
			$Jour = date("d");
			
			if ($this->An == $An && $this->Mois == $Mois && $this->Jour == $Jour)
			{
				return true;
			}
			else
			{
				return false;
			}
	}
	
}
?>