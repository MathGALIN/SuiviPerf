<title>SuiviPerf - Noter le poids</title>
<?php
    include("../en_tete.php");
?>

<!-- Conteneur principal avec style similaire à la page graphique -->
<div class="container mt-5 p-4 bg-white rounded-3 shadow" style="max-width:700px;">
    <h1 class="text-center text-success mb-4">Inscrivez vos informations</h1>

    <form action="noterPoidsSQL.php" method="get" class="fs-5">
        <div class="mb-3 row align-items-center">
            <label class="col-sm-4 col-form-label">
                <i class="fas fa-calendar-week"></i> Date
            </label>
            <div class="col-sm-8">
                <input type="date" name="date" class="form-control" 
                       value="<?php echo date('Y-m-d'); ?>">
            </div>
        </div>

        <div class="mb-3 row align-items-center">
            <label class="col-sm-4 col-form-label">
                <i class="fas fa-weight"></i> Poids en kg
            </label>
            <div class="col-sm-8">
                <input type="text" name="poids" class="form-control" placeholder="kg">
            </div>
        </div>

        <div class="text-center mt-4">
            <input type="submit" class="btn btn-success btn-lg" value="Ajouter">
        </div>
    </form>
</div>

<!-- Bootstrap CSS si pas déjà inclus -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
