<?php
	include("../BDD.php");
  	$pseudo = $_COOKIE['connecter'];

	$date = $_GET["date"];
	$poids = $_GET["poids"];
	
	$CBDD_SuiviPerf->InsertPoids($date, $poids);

	
	echo "
	<script>
		window.location.replace('../index.php');
	</script>
	";
?>