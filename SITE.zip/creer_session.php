<?php
	include("Cdate.php");
	include("UTILISATEUR/BDD.php");
	
	$utilisateur = $_GET["utilisateur"];
	$mdp = $_GET["mdp"];

	$aMontre = $_GET["aMontre"];
	
	
	
	$SQL = "
	SELECT COUNT(*) AS 'compte', aMontre FROM utilisateur
	WHERE pseudo = :pseudo AND mdpHASH = :mdp
	";
	
	$ReqPrep = $conn->prepare($SQL);
	$ReqPrep->bindParam(':pseudo', $utilisateur);
	$ReqPrep->bindParam(':mdp', $mdp);
	$ReqPrep->execute();
	
	$compte_pareil = $ReqPrep->fetchAll()['0']['compte'];
	if ($compte_pareil == 1)
	{
		setcookie("connecter", $utilisateur);
		setcookie("aMontre", $aMontre);
		
		$caracteres = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$longueurMax = strlen($caracteres);
		$chaineAleatoire = '';
		for ($i = 0; $i <= 100; $i++)
		{
			$chaineAleatoire .= $caracteres[rand(0, $longueurMax - 1)];
		}
		
		setcookie("token", $chaineAleatoire);
		
		$Cdate = new Cdate();
		$today = $Cdate->GetDate();
		
		$SQL = "
		INSERT INTO `token`(`pseudo`, `token`, `date`) 
		VALUES ('$utilisateur', '$chaineAleatoire' ,'$today')
		"; 

		$conn->query($SQL);
		
		
	
		echo "
			<script>
				document.location.href = 'index.php';
			</script>
		";
	}
	else
	{
		echo "
		<script>
			document.location.href = 'https://legadroit.com/la-cybercriminalite/';
		</script>";
	}

?>