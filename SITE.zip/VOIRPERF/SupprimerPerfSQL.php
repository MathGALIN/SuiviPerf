<title> SuiviPerf - Supprimer perf </title>
<?php

	//On se connecte à la base de donnée et on prend le pseudo
	$pseudo = $_COOKIE['connecter'];
	
	include("../Cdate.php");
	include("../BDD.php");
	
	$an = $_GET["an"];
	$mois = $_GET["mois"];
	$jour = $_GET["jour"];
	$NumExercice = $_GET["NumExercice"];
	
	$date = $an.'-'.$mois.'-'.$jour;
	
	$CBDD_SuiviPerf->DeletePerf($date, $NumExercice);

echo "
<script>
document.location.href = 'VoirPerf.php?NumExercice=$NumExercice';
</script>
";
?>