<?php
include("../BDD.php");
include("../en_tete.php");
include("../Cdate.php");

$pseudo = $_COOKIE['connecter'];
$NumExercice = $_GET["NumExercice"];
$LibelleExercice = $CBDD_SuiviPerf->GetLibelleNumExercice($NumExercice);
$lesLignes = $CBDD_SuiviPerf->GetPerfExercice($NumExercice);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>SuiviPerf - Voir la performance</title>

  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  <style>
    body {
      background-color: #f4f6f8;
      color: #333;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .container {
      margin-top: 50px;
      max-width: 1000px;
      background-color: #fff;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 5px 20px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      margin-bottom: 30px;
      color: #28a745;
    }

    table {
      width: 100%;
    }

    th, td {
      text-align: center;
      padding: 10px;
    }

    th {
      background-color: #28a745;
      color: #fff;
    }

    tr:nth-child(even) {
      background-color: #f2f2f2;
    }

    i.fas.fa-trash {
      color: #dc3545;
      cursor: pointer;
      transition: transform 0.2s;
    }

    i.fas.fa-trash:hover {
      transform: scale(1.2);
    }

    canvas {
      margin-top: 30px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Performance à l'exercice "<?php echo $LibelleExercice; ?>"</h2>

    <!-- Graphique -->
    <canvas id="myChart" height="120"></canvas>

    <!-- Tableau -->
    <div class="table-responsive mt-4">
      <table class="table table-bordered align-middle">
        <thead>
          <tr>
            <th>Poids haltère</th>
            <th>NbRep</th>
            <th>Poids*NbRep</th>
            <th>Ressentie</th>
            <th>Texte</th>
            <th>Date</th>
            <th>Poids au moment</th>
            <th>Supprimer</th>
          </tr>
        </thead>
        <tbody>
          <?php
          echo "<script>let date = [], multiplication = [];</script>";

          foreach ($lesLignes as $valeur) {
              $Poids = $valeur["PoidsHaltere"] + $valeur["PoidsElastique"];
              $NbRep = $valeur["NbRep"];
              $ressentie = $valeur["Ressentie"];
              $Texte = $valeur["Texte"];
              $isPDC = $valeur["isPDC"];
              
              $Date = new Cdate($valeur["Date"], $pseudo);
              $labelDate = $Date->GetDate();
              $an = $Date->An;
              $mois = $Date->Mois;
              $jour = $Date->Jour;

              $poidsCorps = $CBDD_SuiviPerf->GetPoidsUtilisateur($labelDate);

              if ($isPDC == 0) {
                  $Multiplication = ($Poids == 0) ? $NbRep : $NbRep * $Poids;
              } else {
                  $Poids += $valeur["PoidsLest"];
                  $Multiplication = ($Poids == 0) ? $NbRep * $poidsCorps : $NbRep * ($Poids + $poidsCorps);
              }

              echo "<script>date.push('$labelDate'); multiplication.push($Multiplication);</script>";

              $rowColor = ($NbRep < 5 || $NbRep <= 20) ? '#d4edda' : '#f8d7da';

              echo "
              <tr style='background: $rowColor;'>
                <td>$Poids</td>
                <td>$NbRep</td>
                <td>$Multiplication</td>
                <td>$ressentie</td>
                <td>$Texte</td>
                <td>$labelDate</td>
                <td>$poidsCorps</td>
                <td><i class='fas fa-trash' onclick='Supprimer($an,$mois,$jour)'></i></td>
              </tr>";
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>

  <script>
    // Graphique
    const ctx = document.getElementById("myChart").getContext("2d");
    const myChart = new Chart(ctx, {
      type: "line",
      data: {
        labels: date,
        datasets: [{
          label: "NbRep * Poids",
          data: multiplication,
          backgroundColor: "rgba(40,167,69,0.2)",
          borderColor: "rgba(40,167,69,1)",
          borderWidth: 2,
          fill: true,
          tension: 0.3,
          pointRadius: 5,
          pointBackgroundColor: "rgba(40,167,69,1)"
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: true, position: 'top' },
          tooltip: { mode: 'index', intersect: false }
        },
        scales: {
          x: { title: { display: true, text: 'Date' } },
          y: { title: { display: true, text: 'Poids*NbRep' }, beginAtZero: false }
        }
      }
    });

    // Supprimer
    function Supprimer(an, mois, jour) {
      if (confirm('Voulez-vous vraiment supprimer cette performance ?')) {
        window.location.href = 'SupprimerPerfSQL.php?NumExercice=<?php echo $NumExercice; ?>&an='+an+'&mois='+mois+'&jour='+jour;
      }
    }
  </script>
</body>
</html>
