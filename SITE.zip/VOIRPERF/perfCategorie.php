<title>SuiviPerf - Choisir l'exercice</title>
<?php
include("../BDD.php");
include("../en_tete.php");
include("../Cexercice.php");

$pseudo = $_COOKIE['connecter'];
?>

<style>
body {
    font-family: 'Arial', sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 0;
}

/* Titre de la page */
h1.main-title {
    margin: 10px 0;
    text-align: center;
    color: #333;
}

/* En-tête sticky */
header {
    position: sticky;
    top: 0;
    z-index: 1100;
    background-color: #fff;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

/* Formulaire sticky sous l'en-tête */
.formulaire-container {
    position: sticky;
    top: 60px;
    background-color: #f8f9fa;
    padding: 10px 0;
    z-index: 1000;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
    gap: 15px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

.formulaire-container select,
.formulaire-container input[type="text"] {
    width: 100%;
    padding: 10px 15px;
    border-radius: 8px;
    border: 1px solid #ccc;
    font-size: 1rem;
    transition: all 0.3s;
}
</style>

<h1 class="main-title">Voir les performances</h1>
<hr>

<div class="formulaire-container">
    <div style="flex: 1; min-width: 200px;">
        <select id="numMuscle" onchange="numMuscle()">
            <?php
            $lesLignes = $CBDD_SuiviPerf->GetLesMuscles();
            $numMuscleURL = isset($_GET["numMuscle"]) ? $_GET["numMuscle"] : 0;

            echo "<option value='0'" . ($numMuscleURL == 0 ? " selected" : "") . ">TOUT LES MUSCLES</option>";
            foreach ($lesLignes as $valeur) {
                $Libelle = $valeur["LibelleMUSCLE"];
                $NumMuscle = $valeur["NumMuscle"];
                $selected = ($numMuscleURL == $NumMuscle) ? "selected" : "";
                echo "<option value='$NumMuscle' $selected>$Libelle</option>";
            }
            ?>
        </select>
    </div>
</div>

<br>

<?php
// Ici continue ton code existant pour afficher les exercices
$num_choisie = isset($_GET["numMuscle"]) ? $_GET["numMuscle"] : 0;
$lesLignes = $CBDD_SuiviPerf->GetExoMuscle($num_choisie);
$nb_ligne = 3;
echo "<table align='center'>";
$i = 0;
foreach ($lesLignes as $valeur) {
    if ($i == 0) echo "<tr>";

    $LibelleExercice = $valeur["LibelleExercice"];
    $NumExercice = $valeur["NumExercice"];
    $photo = $valeur["image"];

    echo "<div style='margin-left:50px;'>";
    $exercice = new exercice($LibelleExercice, $NumExercice, $photo);
    $exercice->AfficheExercice(0);
    echo "</div>";

    if ($i == $nb_ligne - 1) {
        $i = 0;
    } else {
        $i += 1;
    }
}
echo "</table>";
?>

<script>
function numMuscle() {
    var numMuscle = document.getElementById("numMuscle").value;
    window.location.replace('perfCategorie.php?numMuscle=' + numMuscle);
}

function dirigeURL(x) {
    document.location.href = "VoirPerf.php?NumExercice=" + x;
}
</script>
