<?php
setcookie('connecter');
unset($_COOKIE['connecter']);

echo "
<script>
	window.location.replace('connexion.php');
</script>";
?>