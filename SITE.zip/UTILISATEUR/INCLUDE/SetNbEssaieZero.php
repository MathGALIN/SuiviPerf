<?php
		$SQL = "
		UPDATE `utilisateur` SET nbTentative = 0
		WHERE pseudo = :pseudo
		";
		
		$ReqPrep = $conn->prepare($SQL);
		$ReqPrep->bindParam(':pseudo', $pseudo);
		$ReqPrep->execute();
?>