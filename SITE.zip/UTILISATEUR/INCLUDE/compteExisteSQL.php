<?php
		$SQL = "
		SELECT COUNT(*) AS 'compte' FROM utilisateur
		WHERE mail = :mail OR
		pseudo = :pseudo
		";
		
		$ReqPrep = $conn->prepare($SQL);
		$ReqPrep->bindParam(':mail', $email);
		$ReqPrep->bindParam(':pseudo', $pseudo);
		$ReqPrep->execute();
		
		$compte_pareil = $ReqPrep->fetchAll()['0']['compte'];
		if ($compte_pareil >= 1)
		{
			$erreur .= "Le compte existe déjà utilisez un autre mail et un autre pseudo<br>";
			$test_valide == false;
		}
?>