<?php

if (filter_var($email, FILTER_VALIDATE_EMAIL) == false) {
  $test_valide = false;
  $erreur .= "L'email rentré n'est pas un email <br>";
}

?>