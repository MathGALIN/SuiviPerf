<?php
	if (	isset($_GET["pseudo"]) && isset($_GET["mdp"]) 		)
	{
		$pseudo = $_GET["pseudo"];
		$mdp = $_GET["mdp"];
		
		if($pseudo == '' || $mdp == '')
		{
			$champ_remplie = false;
		}
	}
	else
	{
		$champ_remplie = false;
	}
	
	if ($champ_remplie == false)
	{
		$message .= "Tout les champs n'ont pas été remplie <br>";
	}
?>