<?php
		$SQL = "
		SELECT SUM(nbTentative) AS 'nbTentative'
		FROM utilisateur
		WHERE pseudo = :pseudo
		";
		
		$ReqPrep = $conn->prepare($SQL);
		$ReqPrep->bindParam(':pseudo', $pseudo);
		$ReqPrep->execute();
		
		$nb_essaie = $ReqPrep->fetchAll()['0']['nbTentative'];
?>