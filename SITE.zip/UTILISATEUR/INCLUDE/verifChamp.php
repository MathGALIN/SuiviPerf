<?php
	if (	isset($_GET["pseudo"]) && isset($_GET["email"]) && isset($_GET["mdp"]) )
	{
		$pseudo = $_GET["pseudo"];
		$email = $_GET["email"];
		$mdp = $_GET["mdp"];
		
		if($pseudo == '' || $email == '' || $mdp == '')
		{
			$champ_remplie = false;
		}
	}
	else
	{
		$champ_remplie = false;
	}


	$aMontre = 0;
	if ( isset($_GET["Amontre"])	)
	{
		$aMontre = $_GET["Amontre"];
		if ($aMontre != 'on')
		{
			$champ_remplie = false;
		}

			$aMontre = 1;
	}

		
	if ($champ_remplie == false)
	{
		$erreur .= "Tout les champs n'ont pas été remplie correctement <br>";
	}
?>