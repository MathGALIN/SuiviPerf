<?php
function encrypt($data, $key) {
    $data = serialize($data);

    // Use AES-256-CBC instead of DES
    $cipher = "AES-256-CBC";
    $ivlen = openssl_cipher_iv_length($cipher);
    $iv = openssl_random_pseudo_bytes($ivlen);

    // Encrypt and base64 encode
    $encrypted = openssl_encrypt('!' . $data, $cipher, $key, 0, $iv);

    // Store IV + encrypted data together
    return base64_encode($iv . $encrypted);
}

function decrypt($data, $key) {
    $cipher = "AES-256-CBC";
    $ivlen = openssl_cipher_iv_length($cipher);

    $data = base64_decode($data);

    // Extract IV and encrypted data
    $iv = substr($data, 0, $ivlen);
    $encrypted = substr($data, $ivlen);

    $decrypted = openssl_decrypt($encrypted, $cipher, $key, 0, $iv);

    if (substr($decrypted, 0, 1) !== '!') {
        return false;
    }

    $decrypted = substr($decrypted, 1);
    return unserialize($decrypted);
}
?>
