<?php
  // Déclaration des constantes de salage
  define('PREFIX_SALT', 'v13 Al1Anc3');
  define('SUFFIX_SALT', 'W3rE we Go ON3 W3 Go A11');
 
  $mdp = md5(PREFIX_SALT.$mdp.SUFFIX_SALT);
?>