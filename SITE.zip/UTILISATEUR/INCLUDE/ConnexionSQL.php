<?php
		$SQL = "
		SELECT COUNT(*) AS 'compte', aMontre FROM utilisateur
		WHERE pseudo = :pseudo AND mdpHASH = :mdp
		";
		
		$ReqPrep = $conn->prepare($SQL);
		$ReqPrep->bindParam(':pseudo', $pseudo);
		$ReqPrep->bindParam(':mdp', $mdp);
		$ReqPrep->execute();
		
		$compte_pareil = $ReqPrep->fetchAll()['0']['compte'];
		if ($compte_pareil == 1)
		{
			
			$test_valide = true;

			$SQL = "SELECT aMontre, isValide FROM utilisateur WHERE pseudo = '$pseudo' ";

			$res = $conn->query($SQL);
			$lesLignes = $res->fetchAll();
			foreach ($lesLignes as $valeur)
			{
				$aMontre = $valeur["aMontre"];
				$isValide = $valeur["isValide"];
			}
			
			if ($isValide == 0)
			{
				$test_valide = false;
				$message .= "Le compte n est pas actif <br>";
			}



		}
		else
		{
			$message .= "Les identifiants ne sont pas valide <br>";
			
			$SQL = "
			UPDATE utilisateur SET 
			nbTentative = nbTentative + 1 
			WHERE pseudo = :pseudo
			";
			
			$ReqPrep = $conn->prepare($SQL);
			$ReqPrep->bindParam(':pseudo', $pseudo);
			$ReqPrep->execute();
			
			
			$test_valide = false;
		}
?>