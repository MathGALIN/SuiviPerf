<?php

	$longueur_mdp = strlen($mdp);
	if ($longueur_mdp <= 5)
	{
		$test_valide = false;
		$erreur .= "Veuillez rentrez un mot de passe de plus de 5 caractere <br>";
	}

?>