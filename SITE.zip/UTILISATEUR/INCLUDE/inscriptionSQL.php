<?php
		$SQL = "
		INSERT INTO `utilisateur`(`mail`, `pseudo`, `mdpHASH`, `aMontre`, `isValide`) 
		VALUES ( :mail , :pseudo ,:mdp, :aMontre, 1 )
		";
		
		$ReqPrep = $conn->prepare($SQL);
		$ReqPrep->bindParam(':mail', $email);
		$ReqPrep->bindParam(':pseudo', $pseudo);
		$ReqPrep->bindParam(':mdp', $mdp);
		$ReqPrep->bindParam(':aMontre', $aMontre);
		$ReqPrep->execute();
?>