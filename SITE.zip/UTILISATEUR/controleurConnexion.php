<?php

//On inclue la BDD :
include("BDD.php");

//On initialise nos test :
$champ_remplie = true;
$test_valide = true;
$message = "";



//On verifie que tout les champs ait bien été remplie
include("INCLUDE/verifChampCo.php");



if ($champ_remplie)
{
	//On vérifie que le nombre de tentative est inferieur à 5
	include("INCLUDE/verifNbEssaie.php");

	//On hache le mot de passe
	include("INCLUDE/hacheMDP.php");
	
	//On vérifie que les informations sont valide
	include("INCLUDE/ConnexionSQL.php");
}


if ($nb_essaie > 5)
{
	$message .= "Le nombre de tentative maximum a déjà été atteint <br>";
	$test_valide = false;
}

if ($test_valide)
{
	//On met le nombre d'esaie qui reste à zéro
	include("INCLUDE/SetNbEssaieZero.php");
	
	echo "
	<script>
		window.location.replace('../creer_session.php?utilisateur=$pseudo&aMontre=$aMontre&mdp=$mdp');
	</script>
	";
}

else
{
	echo "
	<script>
		window.location.replace('connexion.php?message=$message');
	</script>
	";
}
?>