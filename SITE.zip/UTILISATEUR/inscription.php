<title> SuiviPerf - Inscription </title>

<?php
	include("en_tete.php");
?>


<h1>
	Inscrivez vous :
</h1>

<hr>


	<?php 
		if ( isset($_GET["erreur"]) )
		{
			$erreur = $_GET["erreur"];
			echo "
			<div class='alert alert-primary' role='alert'>
			  $erreur
			</div>
			";
		}
	?>


<h2>
	
	<form method='get' action='controleurInscription.php'>
		<table>
		
			<tr>
				<td>
					<label> <i class="fas fa-user"></i> Pseudo : </label>
				</td>
				<td>
					<input type='text' name='pseudo' required>
				</td>
			</tr>
			<tr>
				<td>
					<label> <i class="fas fa-envelope"></i> Email : </label>
				</td>
				<td>
					<input type='email' name='email' required>
				</td>
			</tr>
			<tr>
				<td>
					<label> <i class="fas fa-key"></i> Mot de passe : </label>
				</td>
				<td>
					<input type='password' name='mdp' id='mdp1' required onblur="SamePassword()">
				</td>
			</tr>
			<tr>
				<td>
					<label> <i class="fas fa-key"></i> Confirmer le mot de passe : </label>
				</td>
				<td>
					<input type='password' id='mdp2' required onblur="SamePassword()">
				</td>
			</tr>

			<tr>
				<td>
					<label> <i class="fas fa-clock"></i> A une montre connecter : </label>
				</td>
				<td>
					<input type='checkbox' name='Amontre'>
				</td>
			</tr>

		</table>
		
		<br>
		
		<input type='submit' id='submit' class="btn btn-success btn-lg" value='inscription' disabled>
		
	</form>
</h2>

<script>
	function SamePassword()
	{
		champ1 = document.getElementById('mdp1').value;
		champ2 = document.getElementById('mdp2').value;
		if (champ1 == champ2 && champ1 != '' && champ2 != '')
		{
			document.getElementById('submit').disabled = false;
		}
		else
		{
			document.getElementById('submit').disabled = true;	
		}
	}
</script>