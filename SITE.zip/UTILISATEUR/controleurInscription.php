<?php

//On inclue la BDD :
include("BDD.php");

//On initialise nos test :
$champ_remplie = true;
$test_valide = true;
$erreur = "";

//On verifie que tout les champs ait bien été remplie
include("INCLUDE/verifChamp.php");

if ($champ_remplie)
{
	//On verifie bien que le champ email soit un email
	include("INCLUDE/verifEmail.php");

	//On vérifie que le mot de passe fait plus de 5 caracteres
	include("INCLUDE/verifMDP.php");
	
	if ($test_valide)
	{	
		//On hache le mot de passe
		include("INCLUDE/hacheMDP.php");
		
		//On crypte l'adresse mail
		include("INCLUDE/crypteMail.php");
		$email = encrypt($email, '!#eAm3Q3');
		
		//Verifiez que les entrees n'existent pas déjà dans la BDD
		include("INCLUDE/compteExisteSQL.php");
	}
	
}

//Si il n'y a aucune erreur
if ($erreur == "")
{
	include("INCLUDE/inscriptionSQL.php");
	
	$message = "Le compte a bien été cree";
	echo "
	<script>
		window.location.replace('connexion.php?message=$message');
	</script>
	";
}
else
{
	echo "
	<script>
		window.location.replace('inscription.php?erreur=$erreur');
	</script>
	";
}



?>