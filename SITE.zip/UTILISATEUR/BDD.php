<header>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</header>

<?php

	header( 'content-type: text/html; charset=utf-8' );

	$servername = 'localhost';
	
	//On essaie de se connecter
	try{
		$conn = new PDO("mysql:host=$servername;dbname=SuiviPerf;charset=utf8", 'root', ''); 
		//On définit le mode d'erreur de PDO sur Exception
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}

	/*On capture les exceptions si une exception est lancée et on affiche
	 *les informations relatives à celle-ci*/
	catch(PDOException $e){
	  echo "Erreur : " . $e->getMessage();
	}
	
?>