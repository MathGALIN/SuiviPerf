<title> SuiviPerf - Connexion </title>
<?php
	include("en_tete.php");
?>


<h1>
	Inscrivez vous :
</h1>

<hr>

	<?php 
		if ( isset($_GET["message"]) )
		{
			$message = $_GET["message"];
			echo "
			<div class='alert alert-primary' role='alert'>
			  $message
			</div>
			";
		}
	?>


<h2>
	<form method='get' action='controleurConnexion.php'>
		<table>
		
			<tr>
				<td>
					<label> <i class="fas fa-user"></i> Pseudo : </label>
				</td>
				<td>
					<input type='text' name='pseudo' required>
				</td>
			</tr>
			<tr>
				<td>
					<label> <i class="fas fa-key"></i> Mot de passe : </label>
				</td>
				<td>
					<input type='password' name='mdp' required>
				</td>
				
					
			</tr>
		</table>
		
	<br>
	
	<input type='submit' class="btn btn-success btn-lg" value='connexion'>
			
	</form>
	
	<a href='inscription.php'> S'inscrire </a>

</h2>	
	