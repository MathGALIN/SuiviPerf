<?php
//On récupère nos deux frameworks

	//On obtient l'adresse
	  if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') 
		$adresse = "https"; 
	  else
		$adresse = "http"; 
		
	  // Ajoutez // à l'URL.
	  $adresse .= "://"; 
		
	  // Ajoutez l'hôte (nom de domaine, ip) à l'URL.
	  $adresse .= $_SERVER['HTTP_HOST']; 
		
	  // Ajouter l'emplacement de la ressource demandée à l'URL
	  $fichier = $_SERVER['REQUEST_URI']; 
	  $longueur_fichier = strlen($fichier);
	  $flag = 0;
	  for ($i = 0; $i < $longueur_fichier; $i++)
	  {
		  if ($flag < 2)
		  {
			$adresse .= $fichier[$i];
		  }
		  
		  if ($fichier[$i] == '/')
		  {
			  $flag += 1;
		  }
	  }


//On dirige vers fontawesome qui est installé localement
echo "
<link href='$adresse/Framework/font-awesome/css/all.css' rel='stylesheet'>
";



//On inclue l'installation de bootstrap 

//Le CSS
echo "
<link 
href='$adresse/Framework/bootstrap/bootstrap.min.css' 
rel='stylesheet'
integrity='sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3' 
crossorigin='anonymous'>
";

//Le javascript
echo "
<script 
src='$adresse/Framework/bootstrap/js/bootstrap.bundle.min.js' 
integrity='sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p' 
crossorigin='anonymous'>
</script>
";
?>



<div align='center' id='en_tete'>
	
	SuiviPerf
	<hr>


</div>

<style>
	h1 {
		color: black;
		margin-left: 20px;
	}

	h2 {
		color: black;
		margin-left: 50px;
	}
	
	h3 {
		color: black;
		margin-left: 90px;
	}

	p {
		margin-left:  50px;
		margin-bottom: -10px;
	}


	a {
		color: purple;
		margin-left: 50px;
	}
	
	a:link 
	{ 
		text-decoration:none; 
	} 
	
	input[type="submit"]{
		font-size: 30px;
	}
	
	#en_tete {
		background: orange;
		font-size: 50px; 
		color: ghostwhite;
		
		position: -webkit-sticky;
		position: sticky;
		top: 0px;
	}

</style>