<?php
class exercice
{
	public $LibelleExercice;
	public $NumExercice;
	public $photo;
	
	
	function __construct($LibelleExercice, $NumExercice, $photo)
	{
		$this->LibelleExercice = $LibelleExercice;
		$this->NumExercice = $NumExercice;
		$this->photo = $photo;
	}
	
	function AfficheExercice($serie)
	{
		$NumExercice = $this->NumExercice;
		$photo = $this->photo;
		$LibelleExercice = $this->LibelleExercice;
		
		if ($serie == 0)
		{
			echo "
			<td onclick='dirigeURL($NumExercice)'>		
				<div class='card border-primary border-2' style='width: 22rem; height: 25rem;'>
				<img class='card-img-top' src='../imgExercice/$photo' alt='$photo' style='width:21rem; height:15rem; margin-left:0.25rem; margin-top:8px;'>
				<h1 align='center' class='card-title' style='height:3rem;'> $LibelleExercice </h1>
				<a>
				<br>
			</td>
			";
		}
		else
		{
			echo "	
			<div class='card border-primary border-2' style='width: 22rem; height: 25rem; margin-left: 35%;'>
			<img class='card-img-top' src='../imgExercice/$photo' alt='$photo' style='width:21rem; height:15rem; margin-left:0.25rem; margin-top:8px;'>
			<h1 align='center' class='card-title' style='height:3rem;'> 
			$LibelleExercice <br>
			$serie <br>
			<span id='time'>00:00</span> <br> <br>
			</h1>
			</div>
			";	
		}
	}
	
	
}
?>