<header>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</header>



<?php

	//On obtient l'adresse
	  if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') 
		$adresse = "https"; 
	  else
		$adresse = "http"; 
		
	  // Ajoutez // à l'URL.
	  $adresse .= "://"; 
		
	  // Ajoutez l'hôte (nom de domaine, ip) à l'URL.
	  $adresse .= $_SERVER['HTTP_HOST']; 
		
	  // Ajouter l'emplacement de la ressource demandée à l'URL
	  $fichier = $_SERVER['REQUEST_URI']; 
	  $longueur_fichier = strlen($fichier);
	  $flag = 0;
	  for ($i = 0; $i < $longueur_fichier; $i++)
	  {
		  if ($flag < 2)
		  {
			$adresse .= $fichier[$i];
		  }
		  
		  if ($fichier[$i] == '/')
		  {
			  $flag += 1;
		  }
	  }
	
	$existeCookie = isset($_COOKIE['connecter']) ;
	$cookienul = "";
	if ($existeCookie == true)
	{
		$valeur = $_COOKIE['connecter'];
		
		if ($valeur == "")
		{
			$cookienul = true;
		}
	}
	
	if (	$existeCookie == false || $cookienul == true	)
	{
		$message = "Connectez vous pour accéder au site";
		echo "
		<script>
			document.location.href = '$adresse/UTILISATEUR/connexion.php?message=$message';
		</script>
		";
	}
	
	
	
	
	
	
	class BDD {
		
		public $servername;
		public $username;
		public $password;
		public $pseudo;
		public $token;
		public $conn;
		
		
		/*
		Les conventions de codage de la classe :
		- A chaque fois qu'un objet est envoyer en paramètre d'une fonction on exécute une requête paramétré
		- Si renvoie de Valeur Get
		- Si modification Update
		- Si supression Delete
		- Si création de valeur Create
		*/
		
		//Construit l'objet
		function __construct($pseudo="", $token="IsOkayVerificationNotRequiredAka123456789")
		{
			$this->servername = 'localhost';
			$this->username = 'root';
			$this->password = '';
			$this->pseudo = $pseudo;
			$this->token = $token;
			$this->conn = $this->GetConn();
			
			//On vérifie que le token est exact
			if ($token != "IsOkayVerificationNotRequiredAka123456789")
			{
				$this->VerifieCompte();
			}
		}
		
		
		//Vérifie que le pseudo et le token correspondent
		function VerifieCompte()
		{
			$pseudo = $this->pseudo;
			$token = $this->token;
			
			$compte = $this->GetPseudoToken($pseudo, $token);
			if ($compte == 0)
			{
				echo "
				<script>
					document.location.href = 'https://legadroit.com/la-cybercriminalite/';
				</script>
				";
			}
			
			
		}
		
		
		
		
		
		
		
		
		
		
		//Renvoie le connecteur
		function GetConn()
		{
			$servername = $this->servername;
			$username = $this->username;
			$password = $this->password;
			
			//On essaie de se connecter
			try{
				$conn = new PDO("mysql:host=$servername;dbname=SuiviPerf;charset=utf8", $username, $password); 
				//On définit le mode d'erreur de PDO sur Exception
				$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				return $conn;
			}

			/*On capture les exceptions si une exception est lancée et on affiche
			 *les informations relatives à celle-ci*/
			catch(PDOException $e){
			  echo "Erreur : " . $e->getMessage();
			}
			
		}
		
		
		
		
		
		
		
		
		
		//Renvoie le fait qu'il y'ai un token
		function GetPseudoToken($pseudo, $token)
		{
			$SQL = "
			SELECT COUNT(*) AS 'EXISTE'
			FROM token
			WHERE pseudo = '$pseudo' AND
			token = '$token'
			";	

			$les_valeurs = $this->RenvoieTableau($SQL);
			return $les_valeurs[0]["EXISTE"];
		}
		
		
		
		
		
		//Renvoie le fait que l'exercice soit pdc ou pas
		function IsPDC($NumExercice)
		{
			$SQL = "
			SELECT exercice.isPDC FROM exercice
			WHERE NumExercice = :NumExercice
			";
			
			$liste_param = array();
			$liste_param[":NumExercice"] = $NumExercice;
			
			$les_valeurs = $this->RenvoieTableau($SQL, $liste_param);
			if ( $les_valeurs[0]["isPDC"] == 0)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		
		//Renvoie le libelle selon le numero de l'exercice
		function GetLibelleNumExercice($NumExercice)
		{
			$SQL = "
			SELECT LibelleExercice 
			FROM exercice
			WHERE NumExercice = :NumExercice
			";
			
			$liste_param = array();
			$liste_param[":NumExercice"] = $NumExercice;
			
			$les_valeurs = $this->RenvoieTableau($SQL, $liste_param);
			
			return $les_valeurs[0]["LibelleExercice"];
		}
		
		
		//La fonction Renvoie tout les aliments
		function GetLesAliments()
		{
			$SQL = "
			SELECT * FROM `aliment`
			ORDER BY IdCategorieA, LibelleAliment
			";
			
			$les_valeurs = $this->RenvoieTableau($SQL);
			return $les_valeurs;
		}
		
		
		//La fonction Renvoie toutes les Set d'aliments
		function GetLesCategoriesAliments()
		{
			$SQL = "
			SELECT * FROM `categoriealiment`
			";
			
			$les_valeurs = $this->RenvoieTableau($SQL);
			return $les_valeurs;
		}
		
		
		//La fonction renvoie le nom des muscles
		function GetLesMuscles()
		{
			$SQL = "
			SELECT LibelleMUSCLE, NumMuscle FROM muscle ORDER BY LibelleMUSCLE
			";
			
			$les_valeurs = $this->RenvoieTableau($SQL);
			return $les_valeurs;
		}
		
		
		
		//Renvoie les exercices du muscle choisie
		function GetExoMuscle($num_muscle)
		{
			$pseudo = $this->pseudo;
			
			$SQL = "
			SELECT 
			DISTINCT LibelleExercice, exercice.NumExercice, exercice.image 
			FROM exercice
			WHERE IsEval = 1
			
			AND NumExercice 
			IN (SELECT muscexo.NumExercice FROM muscexo WHERE muscexo.NumMuscle = :num_muscle OR :num_muscle = 0)
			
			AND NumExercice IN (SELECT NumExercice FROM perfdate WHERE pseudo = '$pseudo' )
			";
			
			$liste_param = array();
			$liste_param[":num_muscle"] = $num_muscle;
			
			$les_valeurs = $this->RenvoieTableau($SQL, $liste_param);
			return $les_valeurs;
			
		}
		
		
		
		//Renvoie les poids de l'utilisateur
		function GetLesPoids()
		{
			$pseudo = $this->pseudo;

			$SQL = "
			SELECT DISTINCT * 
			FROM infocorps WHERE pseudo = '$pseudo' 
			";
			
			$les_valeurs = $this->RenvoieTableau($SQL);
			return $les_valeurs;
		}
		
		
		
		//Renvoie les repos de l'utilisateur
		function GetLesRepos()
		{
			$pseudo = $this->pseudo;
			
			$SQL = "SELECT
			SemaineRepos,
			DATEDIFF(NOW(), SemaineRepos ) AS 'DIF'
			FROM semainerepos WHERE pseudo = '$pseudo'
			ORDER BY SemaineRepos
			";
			
			$les_valeurs = $this->RenvoieTableau($SQL);
			return $les_valeurs;	
			
		}
		
		
		
		
		//Renvoie les entraînements de l'utilisateur
		function GetDernierEntrainement()
		{
			$pseudo = $this->pseudo;
			
			$SQL = "
			SELECT DISTINCT MAX(Date) AS 'Date' 
			FROM perfdate 
			WHERE pseudo = '$pseudo' ;
			";
			
			$les_valeurs = $this->RenvoieTableau($SQL);
			return $les_valeurs[0]['Date'];	
		}
		
		
		
		//Renvoie les entraînements personnel de l'utilisateur
		function GetMesEntrainement()
		{
			$pseudo = $this->pseudo;

			$SQL = "
			SELECT * FROM entrainement 
			WHERE pseudo = '$pseudo'
			ORDER BY NumEntrainement
			";
			
			$les_valeurs = $this->RenvoieTableau($SQL);
			return $les_valeurs;
		}
		
		
		
		//Renvoie les entraînements partagés
		function GetLesEntrainementPartager()
		{
			$SQL = "
			SELECT entrainement.* 
			FROM `entrainement`, partageentrainement  
			WHERE
			entrainement.NumEntrainement = partageentrainement.NumEntrainement AND
			entrainement.pseudo = partageentrainement.pseudo
			ORDER BY entrainement.pseudo, entrainement.NumEntrainement
			";
			
			$les_valeurs = $this->RenvoieTableau($SQL);
			return $les_valeurs;
		}
		
		
		
		//Renvoie les Set de l'entraînement personnel
		function GetMesCategories($numEntrainement)
		{
			
			$pseudo = $this->pseudo;
			
			$SQL = "
			SELECT * FROM categorie 
			WHERE NumEntrainement = :numEntrainement 
			AND pseudo = '$pseudo' ORDER BY NumCategorie
			";
			
			$liste_param = array();
			$liste_param[":numEntrainement"] = $numEntrainement;
			
			$les_valeurs = $this->RenvoieTableau($SQL, $liste_param);
			return $les_valeurs;
		}
		
		//Renvoie les Set du propriétais
		function GetLesCategoriesProprietaire($numEntrainement, $proprietaire)
		{
			$SQL = "
			SELECT * FROM categorie 
			WHERE NumEntrainement = :numEntrainement 
			AND pseudo = :proprietaire ORDER BY NumCategorie
			";
			
			$liste_param = array();
			$liste_param[":numEntrainement"] = $numEntrainement;
			$liste_param[":proprietaire"] = $proprietaire;
			
			$les_valeurs = $this->RenvoieTableau($SQL, $liste_param);
			return $les_valeurs;
		}
		
		
		
		//Renvoie les poids de la Set de l'entraînement
		function GetLesPoidsCategories($numEntrainement, $numCategorie)
		{
			$pseudo = $this->pseudo;
			
			$SQL = "
			SELECT PoidsCategorieHaltere, PoidsCategorieLest, PoidsCategorieElastique 
			FROM categorie 
			WHERE NumEntrainement = :numEntrainement 
			AND NumCategorie = :numCategorie 
			AND pseudo = '$pseudo'
			";
			
			$liste_param = array();
			$liste_param[":numEntrainement"] = $numEntrainement;
			$liste_param[":numCategorie"] = $numCategorie;
			
			$les_valeurs = $this->RenvoieTableau($SQL, $liste_param);
			return $les_valeurs;
		}
		
		
		
		//Renvoie les exercices de la categorie de l'utilisateur
		function GetLesExercicesCategorie($numEntrainement, $numCategorie)
		{
			$pseudo = $this->pseudo;
			
			$SQL = "
				SELECT DISTINCT NumExercice 
				FROM ordrecategorie
				WHERE NumEntrainement = :numEntrainement AND 
				NumCategorie = :numCategorie 
				AND pseudo = '$pseudo'
			";
			
			$liste_param = array();
			$liste_param[":numEntrainement"] = $numEntrainement;
			$liste_param[":numCategorie"] = $numCategorie;
			
			$les_valeurs = $this->RenvoieTableau($SQL, $liste_param);
			return $les_valeurs;
		}
		
		
		
		//Renvoie les résultats de la dernière perf de l'utilisateur à l'exercice
		function GetDernierePerfExercice($NumExercice)
		{
		    $pseudo = $this->pseudo;

		    $SQL = "
		    SELECT NbRep 
		    FROM perfdate
		    WHERE NumExercice = :NumExercice
		    AND perfdate.pseudo = :pseudo
		    ORDER BY Date DESC
		    LIMIT 1
		    ";
		    
		    $liste_param = array();
		    $liste_param[":NumExercice"] = $NumExercice;
		    $liste_param[":pseudo"] = $pseudo;
		    
		    $les_valeurs = $this->RenvoieTableau($SQL, $liste_param);
		    return $les_valeurs;
		}
		
		
		
		//Renvoie nos exercices de la catégorie de l'entraînement
		function GetMesExercicesCategories($entrainement, $categorie)
		{
			$pseudo = $this->pseudo;
			
			$SQL = "
			SELECT DISTINCT
			ordrecategorie.NumEntrainement, 
			ordrecategorie.NumCategorie, 
			ordrecategorie.NumExercice, 
			ordrecategorie.Ordre,
			exercice.LibelleExercice,
			exercice.TempsExercice,
			exercice.NbSerie,
			exercice.isEval,
			categorie.LibelleCategorie

			FROM ordrecategorie, categorie, exercice

			WHERE 
			exercice.NumExercice = ordrecategorie.NumExercice	AND
			categorie.NumCategorie = ordrecategorie.NumCategorie	AND
			ordrecategorie.NumEntrainement = categorie.NumEntrainement	AND
			ordrecategorie.NumEntrainement = :entrainement	AND 
			ordrecategorie.NumCategorie = :categorie	AND
			ordrecategorie.pseudo = '$pseudo'
			
			ORDER BY ordrecategorie.Ordre
			";
			
			$liste_param = array();
			$liste_param[":entrainement"] = $entrainement;
			$liste_param[":categorie"] = $categorie;
			
			$les_valeurs = $this->RenvoieTableau($SQL, $liste_param);
			return $les_valeurs;
			
		}
		
		
		
		//Renvoie les exercices de la catégorie de l'entraînement du propriétaire
		function GetLesExercicesCategoriesProprietaire($entrainement, $categorie, $proprietaire)
		{
			$SQL = "
				SELECT DISTINCT
				ordrecategorie.NumEntrainement, 
				ordrecategorie.NumCategorie, 
				ordrecategorie.NumExercice, 
				ordrecategorie.Ordre,
				exercice.LibelleExercice,
				exercice.TempsExercice,
				exercice.NbSerie,
				exercice.isEval,
				categorie.LibelleCategorie

				FROM ordrecategorie, categorie, exercice

				WHERE 
				exercice.NumExercice = ordrecategorie.NumExercice	AND
				categorie.NumCategorie = ordrecategorie.NumCategorie	AND
				ordrecategorie.NumEntrainement = categorie.NumEntrainement	AND
				ordrecategorie.NumEntrainement = :entrainement	AND 
				ordrecategorie.NumCategorie = :categorie AND
				ordrecategorie.pseudo = :proprietaire

				ORDER BY ordrecategorie.Ordre
			";
			
			$liste_param = array();
			$liste_param[":entrainement"] = $entrainement;
			$liste_param[":categorie"] = $categorie;
			$liste_param[":proprietaire"] = $proprietaire;			
			
			
			$les_valeurs = $this->RenvoieTableau($SQL, $liste_param);
			return $les_valeurs;
			
		}
		
		
		
		//Renvoie les informations de l'exercice
		function GetInfoExercice($NumExercice)
		{
			$SQL = "
			SELECT * 
			FROM exercice
			WHERE NumExercice = :NumExercice
			";
			
			$liste_param = array();
			$liste_param[":NumExercice"] = $NumExercice;
			
			$les_valeurs = $this->RenvoieTableau($SQL, $liste_param);
			
			return $les_valeurs;			
		}
		
		
		
		//Renvoie la perf max pour cet exercice au poids donné
		function GetPerfMaxExercice($NumExercice)
		{
			$pseudo = $this->pseudo;
			
			//Si l'exercice est un exercice PDC
			if ($this->IsPDC($NumExercice))
			{
				$SQL = "
				SELECT PoidsHaltere+PoidsLest+PoidsElastique AS 'poids', NbRep AS 'MAX' FROM perfdate 
				WHERE NumExercice = :NumExercice
				AND PoidsHaltere+PoidsLest+PoidsElastique IN (
				SELECT MAX(PoidsHaltere+PoidsLest+PoidsElastique) FROM perfdate WHERE pseudo = '$pseudo' AND NumExercice = :NumExercice)
				AND perfdate.pseudo = '$pseudo'
				ORDER BY NbRep DESC LIMIT 1
				";
			}
		
			//Si l'exercice n'est pas un exercice PDC (on ne prend pas en compte le poids pdc)
			else 
			{
				$SQL = "
				SELECT PoidsHaltere+PoidsElastique AS 'poids', NbRep AS 'MAX' FROM perfdate 
				WHERE NumExercice = :NumExercice
				AND PoidsHaltere+PoidsElastique IN (
				SELECT MAX(PoidsHaltere+PoidsElastique) FROM perfdate WHERE pseudo = '$pseudo' AND NumExercice = :NumExercice)
				AND perfdate.pseudo = '$pseudo'
				ORDER BY NbRep DESC LIMIT 1
				";
			}
						
			$liste_param = array();
			$liste_param[":NumExercice"] = $NumExercice;
			
			$les_valeurs = $this->RenvoieTableau($SQL, $liste_param);
			return $les_valeurs;
			
		}
		
		
		
		//Savoir si un entraînement est partagé
		function GetIsPartageNumEntrainement($NumEntrainement)
		{
			$pseudo = $this->pseudo;

			$SQL = "
			SELECT COUNT(*) AS 'existe' FROM `partageentrainement` 
			WHERE NumEntrainement = :NumEntrainement 
			AND pseudo = '$pseudo'
			";
			
			$liste_param = array();
			$liste_param[":NumEntrainement"] = $NumEntrainement;
		
			$les_valeurs = $this->RenvoieTableau($SQL, $liste_param);
			return $les_valeurs[0]["existe"];		
		}
		
		
		
		//Récupère le numéro de la catégorie à insérer
		function GetNumeroCategorieInserer($numEntrainement)
		{
			
			$pseudo = $this->pseudo;
						
			$SQL = "
			SELECT MAX(NumCategorie)+1 AS 'numero' 
			FROM categorie
			WHERE pseudo = '$pseudo'	AND
			NumEntrainement = :numEntrainement
			";
			
			$liste_param = array();
			$liste_param[":numEntrainement"] = $numEntrainement;
			
			$les_valeurs = $this->RenvoieTableau($SQL, $liste_param);
			return $les_valeurs[0]["numero"];
			
			
		}
		
		//Donne le numéro de l'entraînement à insérer
		function GetNumeroEntrainementInserer()
		{
			
			$pseudo = $this->pseudo;
						
			$SQL = "
			SELECT MAX(NumEntrainement)+1 AS 'numero' 
			FROM entrainement WHERE pseudo = '$pseudo'
			";
			
			
			$les_valeurs = $this->RenvoieTableau($SQL);
			return $les_valeurs[0]["numero"];
		}
		
		
		
		//Donne les informations de la montre
		function GetInfoMontre()
		{
			$pseudo = $this->pseudo;
			
			$SQL = "SELECT * FROM `montre` 
			WHERE pseudo = '$pseudo' ";
			
			$les_valeurs = $this->RenvoieTableau($SQL);
			return $les_valeurs;
		}
		
		
		
		//Renvoie le dernier poids de l'utilisateur
		function GetPoidsUtilisateur($date)
		{
			
			$pseudo = $this->pseudo;
			
			$SQL = "
			SELECT kg, ABS(DATEDIFF(infocorps.Date, :date)) 
			AS 'DIF' 
			FROM infocorps 
			WHERE pseudo = '$pseudo'
			ORDER BY DIF LIMIT 1
			";
			


			$liste_param = array();
			$liste_param[":date"] = $date;
			
			$les_valeurs = $this->RenvoieTableau($SQL, $liste_param);
			return $les_valeurs[0]['kg'];
		}
		
		
		
		//Renvoie les performances de l'exercice
		function GetPerfExercice($NumExercice)
		{

			$pseudo = $this->pseudo;
			
			$SQL = "
			SELECT DISTINCT perfdate.*, exercice.isPDC, exercice.LibelleExercice 
			FROM perfdate, exercice 
			
			WHERE perfdate.NumExercice= :NumExercice 
			AND perfdate.NumExercice = exercice.NumExercice 
			AND perfdate.pseudo = '$pseudo' ORDER BY Date";

			$liste_param = array();
			$liste_param[":NumExercice"] = $NumExercice;
			
			$les_valeurs = $this->RenvoieTableau($SQL, $liste_param);
			return $les_valeurs;
		}
		
		
		
		//Renvoie la liste des exercices
		function GetListeExercice($NumEntrainement, $NumCategorie)
		{
			
			$pseudo = $this->pseudo;
			
			$SQL = "
			SELECT DISTINCT NumExercice, Ordre
			FROM ordrecategorie
			WHERE NumEntrainement = :NumEntrainement
			AND NumCategorie = :NumCategorie
			AND pseudo = '$Pseudo'
			ORDER BY Ordre
			"; 
			
			$liste_param = array();
			$liste_param[":NumEntrainement"] = $NumEntrainement;
			$liste_param[":NumCategorie"] = $NumCategorie;
			
			$les_valeurs = $this->RenvoieTableau($SQL, $liste_param);
			return $les_valeurs;
		}
		
		
		
		//Renvoie les jours ou l'on s'est entraîner
		function GetJourEntrainement($an, $mois)
		{
			$pseudo = $this->pseudo;
			
			$SQL = "
			SELECT DISTINCT Day(Date) AS 'jour'
			FROM perfdate

			WHERE Year(Date) = :an
			AND Month(Date) = :mois
			AND pseudo = '$pseudo'
			";
			
			$liste_param = array();
			$liste_param[":an"] = $an;
			$liste_param[":mois"] = $mois;
			
			$les_valeurs = $this->RenvoieTableau($SQL, $liste_param);
			return $les_valeurs;
		}
		
		
		
		//Renvoie la durée de l'entrainement
		function GetTempsEntrainement($NumEntrainement)
		{
			$pseudo = $this->pseudo;
			
			$SQL = "
			SELECT ROUND(SUM(exercice.NbSerie * exercice.TempsExercice)/60) AS 'TEMPS'

			FROM ordrecategorie, exercice
			WHERE ordrecategorie.NumEntrainement = :NumEntrainement
			AND ordrecategorie.pseudo = '$pseudo'
			AND ordrecategorie.NumExercice = exercice.NumExercice
			";
			
			$liste_param = array();
			$liste_param[":NumEntrainement"] = $NumEntrainement;

			$les_valeurs = $this->RenvoieTableau($SQL, $liste_param);
			return $les_valeurs[0]["TEMPS"];
		}
		
		
		
		
		
		
		
		
		
		
		//Insère dans la BDD une nouvelle catégorie
		function InsertNouvelleCategorie($numero, $nom, $numEntrainement)
		{

			$pseudo = $this->pseudo;
			
			$SQL = "
			INSERT INTO `categorie`
			(`NumCategorie`, `LibelleCategorie`, `PoidsCategorieHaltere`, `PoidsCategorieLest`, `NumEntrainement`, `pseudo`) 
			VALUES (:numero ,:nom, 0, 0, :numEntrainement, '$pseudo')
			";
			
			$liste_param = array();
			$liste_param[":numero"] = $numero;
			$liste_param[":nom"] = $nom;
			$liste_param[":numEntrainement"] = $numEntrainement;
			
			$this->Execute($SQL, $liste_param);	
		}
		
		//Insère dans la BDD un nouveau entraînement
		function InsertNouvelEntrainement($numero, $nom, $type)
		{

			$pseudo = $this->pseudo;
			
			$SQL = "
			INSERT INTO `entrainement`(`NumEntrainement`, `Libelle`, `Type`, `pseudo`) 
			VALUES (:numero, :nom , :type , '$pseudo' )
			";
			
			$liste_param = array();
			$liste_param[":numero"] = $numero;
			$liste_param[":nom"] = $nom;
			$liste_param[":type"] = $type;
			
			$this->Execute($SQL, $liste_param);	
		}
		
		
		
		//Insère dans la BDD la fonctionnalité permettant de partager un entraînement
		function InsertPartagerUnEntrainement($entrainement)
		{
			
			$pseudo = $this->pseudo;
			
			$SQL = "
			INSERT INTO `partageentrainement` 
			(`NumEntrainement`, `pseudo`) 
			VALUES (:entrainement, '$pseudo');
			";
			
			$liste_param = array();
			$liste_param[":entrainement"] = $entrainement;
			
			$this->Execute($SQL, $liste_param);
			
		}
		
		
		
		//Insère une perf dans la BDD
		function InsertPerf($numExercice, $nombreRep, $PoidsHaltere, $PoidsLest, $poidsElastique, $ressentie, $texte, $date, $pseudo)
		{
			$poidsHaltere = $poidsHaltere / 2;
			$pseudo = $this->pseudo;
			
			$SQL = "
			INSERT INTO 
			`SuiviPerf`.`perfdate` (`NumExercice`, `NbRep`, `PoidsHaltere`, `PoidsLest` , `PoidsElastique`,`Ressentie`, `Texte`, `Date`, `pseudo`) 
			VALUES (:numExercice, :nombreRep, :PoidsHaltere, :PoidsLest, :poidsElastique ,:ressentie, :texte, :date, '$pseudo');
			";
			
			$liste_param = array();
			$liste_param[":numExercice"] = $numExercice;
			$liste_param[":nombreRep"] = $nombreRep;
			$liste_param[":PoidsHaltere"] = $PoidsHaltere;
			$liste_param[":PoidsLest"] = $PoidsLest;
			$liste_param[":poidsElastique"] = $poidsElastique;
			$liste_param[":ressentie"] = $ressentie;
			$liste_param[":texte"] = $texte;
			$liste_param[":date"] = $date;
			
			$this->Execute($SQL, $liste_param);
		}
		
		//Insère un poids dans la BDD
		function InsertPoids($date, $poids)
		{
			
			$pseudo = $this->pseudo;
			
			$SQL = "
			INSERT INTO infocorps
			(`Date`, `kg`, `pseudo`) 
			VALUES (:date, :poids, '$pseudo');
			";
			
			$liste_param = array();
			$liste_param[":date"] = $date;
			$liste_param[":poids"] = $poids;
			
			$this->Execute($SQL, $liste_param);
		}
		
		
		
		//Insère une info de la montre dans la BDD
		function InsertMontre($date, $energie, $tempsSeance, $tempsSommeil, $CardMax, $CardMin, $CardMoyenne, $NbPas)
		{
			$pseudo = $this->pseudo;
			
			$SQL = "
			INSERT INTO `montre`
			(`date`, `energie`, `tempsSeance`, `tempsSommeil`, `CardMax`, `CardMin`, `CardMoyenne`, `NbPas`, `pseudo`) 
			VALUES 
			(:date,:energie,:tempsSeance, :tempsSommeil,:CardMax,:CardMin, :CardMoyenne,:NbPas, '$pseudo')
			";
			
			$liste_param = array();
			$liste_param[":date"] = $date;
			$liste_param[":energie"] = $energie;
			$liste_param[":tempsSeance"] = $tempsSeance;
			$liste_param[":tempsSommeil"] = $tempsSommeil;
			$liste_param[":CardMax"] = $CardMax;
			$liste_param[":CardMin"] = $CardMin;
			$liste_param[":CardMoyenne"] = $CardMoyenne;
			$liste_param[":NbPas"] = $NbPas;
			
			$this->Execute($SQL, $liste_param);
			
		}
		
		
		
		
		
		
		
		
		
		
		//Change le poids d'un entrainement et d'une catégorie
		function UpdatePoidsEntrainementCategorie($poidsHaltere, $poidsLest, $poidsElastique, $numCategorie, $numEntrainement)
		{
			$pseudo = $this->pseudo;
						
			$SQL = " 
			UPDATE categorie SET
			PoidsCategorieHaltere = :poidsHaltere , 
			poidsCategorieLest = :poidsLest,
			poidsCategorieElastique = :poidsElastique
			WHERE NumCategorie = :numCategorie AND
			NumEntrainement = :numEntrainement AND
			pseudo = '$pseudo'
			";
			
			$liste_param = array();
			$liste_param[":poidsHaltere"] = $poidsHaltere;
			$liste_param[":poidsLest"] = $poidsLest;
			$liste_param[":poidsElastique"] = $poidsElastique;
			$liste_param[":numCategorie"] = $numCategorie;
			$liste_param[":numEntrainement"] = $numEntrainement;
			
			
			$this->Execute($SQL, $liste_param);
		}
		
		
		
		
		
		
		
		
		
		
		//Supprime de la base de donnée un entrainement partagé
		function DeletePartageEntrainement($entrainement)
		{
			$pseudo = $this->pseudo;
			
			$SQL = "
			DELETE FROM `partageentrainement` 
			WHERE pseudo = '$pseudo' 
			AND NumEntrainement = :entrainement
			";
			
			$liste_param = array();
			$liste_param[":entrainement"] = $entrainement;
			
			$this->Execute($SQL, $liste_param);
		}
		
		
		
		//Supprime de la BDD tout les entraînement
		function DeleteEntrainement($entrainement)
		{
			
			$pseudo = $this->pseudo;
			
			$SQL = "
			DELETE FROM `entrainement` 
			WHERE NumEntrainement = :entrainement 
			and pseudo = '$pseudo'
			";
			
			$liste_param = array();
			$liste_param[":entrainement"] = $entrainement;
			
			$this->Execute($SQL, $liste_param);
		}
		
		
		
		//Supprime de la BDD toutes les Set de l'entrainement
		function DeleteCategorieEntrainement($entrainement)
		{
			
			$pseudo = $this->pseudo;
			
			$SQL = "
			DELETE FROM `categorie` 
			WHERE NumEntrainement = :entrainement 
			and pseudo = '$pseudo'
			";
		
			$liste_param = array();
			$liste_param[":entrainement"] = $entrainement;
			
			$this->Execute($SQL, $liste_param);
		}
		
		
		
		//Supprime de la BDD tout les exercice de l'entrainement
		function DeleteExerciceEntrainement($entrainement)
		{
		
			$pseudo = $this->pseudo;

			$SQL = "
			DELETE FROM `ordrecategorie`
			WHERE NumEntrainement = :entrainement 
			and pseudo = '$pseudo'
			";
			
			$liste_param = array();
			$liste_param[":entrainement"] = $entrainement;
			
			$this->Execute($SQL, $liste_param);
		}
		
		
		
		//Supprime de la BDD la catégorie de l'entrainement
		function DeleteCategorieEntrainementCategorie($categorie, $entrainement)
		{
			
			$pseudo = $this->pseudo;
			
			$SQL = "
			DELETE FROM `categorie` 
			WHERE NumCategorie = :categorie
			AND NumEntrainement = :entrainement
			AND pseudo = '$pseudo'
			";
			
			$liste_param = array();
			$liste_param[":entrainement"] = $entrainement;
			$liste_param[":categorie"] = $categorie;
			
			$this->Execute($SQL, $liste_param);
		}
		
		
		
		//Supprime de la BDD les exercices de la categorie et de l'entrainement
		function DeleteExerciceEntrainementCategorie($categorie, $entrainement)
		{
			$pseudo = $this->pseudo;
			
			$SQL = "
			DELETE FROM `ordrecategorie`
			WHERE NumCategorie = :categorie
			AND NumEntrainement = :entrainement
			AND pseudo = '$pseudo'
			";
			
			$liste_param = array();
			$liste_param[":entrainement"] = $entrainement;
			$liste_param[":categorie"] = $categorie;
			
			$this->Execute($SQL, $liste_param);
		}
		
		
		
		//Supprime de la BDD la performance
		function DeletePerf($date, $numExercice)
		{
			$pseudo = $this->pseudo;
			
			$SQL = "
			DELETE FROM `perfdate` 
			WHERE pseudo = '$pseudo' AND
			Date = :date AND NumExercice = :numExercice
			";

			$liste_param = array();
			$liste_param[":date"] = $date;
			$liste_param[":numExercice"] = $numExercice;
			
			$this->Execute($SQL, $liste_param);
		}
		
		
		
		//Supprime de la BDD l'info de la montre
		function DeleteMontre($date)
		{
			
			$pseudo = $this->pseudo;

			$SQL = "
			DELETE FROM `montre` 
			WHERE pseudo = '$pseudo' 
			AND date = :date";
			
			$liste_param = array();
			$liste_param[":date"] = $date;
			$this->Execute($SQL, $liste_param);
			
		}
		//Supprime de la BDD le poids
		function DeletePoids($date)
		{
			$pseudo = $this->pseudo;
			
			$SQL = "
			DELETE FROM `infocorps` 
			WHERE pseudo = '$pseudo' 
			AND Date = :date
			";

			$liste_param = array();
			$liste_param[":date"] = $date;
			$this->Execute($SQL, $liste_param);
			
		}
		
		
		
		
		
		
		
		
		
		
		//Renvoie le tableau SQL de la requête
		function RenvoieTableau($SQL, $liste_param = null)
		{
			$conn = $this->conn;
			
			if ($liste_param == null)
			{
				$res = $conn->query($SQL);				
			}
			if ($liste_param != null)
			{
				$res = $this->Parametre($conn, $liste_param, $SQL);
				$res->execute();
			}

			$lesLignes = $res->fetchAll();
			return $lesLignes;
		}
		
		
		
		
		//Execute dans la BDD la requête
		function Execute($SQL, $liste_param = null)
		{
			
			
			$conn = $this->conn;
			
			if ($liste_param == null)
			{
				$res = $conn->query($SQL);				
			}
			if ($liste_param != null)
			{
				$res = $this->Parametre($conn, $liste_param, $SQL);
			}
			
			$res->execute();
			
		}
		
		
		//Paramètre la requête
		function Parametre($conn, $liste_param, $SQL)
		{
			$res = $conn->prepare($SQL);
				
			foreach($liste_param as $key => $value)
			{
				$res->bindValue($key, $value);
			}
			
			return $res;
		}
		
		
		
		
		
	}

	
	
	
	
	$pseudo = $_COOKIE["connecter"];
	
	if (isset($_COOKIE["token"]) == true)
	{
		$token = $_COOKIE["token"];
	}
	else
	{
		$token = "NDF";
	}
	
	$CBDD_SuiviPerf = new BDD($pseudo, $token);
	
	$conn = $CBDD_SuiviPerf->conn;
	
?>