<?php
	include("../BDD.php");
  	$pseudo = $_COOKIE['connecter'];

	$date = $_GET["date"];
	$energie = $_GET["energie"];
	$tempsSeance = $_GET["tempsSeance"];
	$tempsSommeil = $_GET["tempsSommeil"];
	$CardMax = $_GET["CardMax"];
	$CardMin = $_GET["CardMin"];
	$CardMoyenne = $_GET["CardMoyenne"];
	$NbPas = $_GET["NbPas"];
	
	$CBDD_SuiviPerf->InsertMontre($date, $energie, $tempsSeance, $tempsSommeil, $CardMax, $CardMin, $CardMoyenne, $NbPas);
	
	echo "
	<script>
		window.location.replace('../index.php');
	</script>
	";
?>