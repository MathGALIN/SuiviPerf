<?php

	//On se connecte à la base de donnée et on prend le pseudo
	$pseudo = $_COOKIE['connecter'];
	
	include("../Cdate.php");
	include("../BDD.php");
	
	$an = $_GET["an"];
	$mois = $_GET["mois"];
	$jour = $_GET["jour"];
	
	$date = $an.'-'.$mois.'-'.$jour;
	
	$CBDD_SuiviPerf->DeleteMontre($date);

echo "
<script>
document.location.href = 'voir.php';
</script>
";
?>