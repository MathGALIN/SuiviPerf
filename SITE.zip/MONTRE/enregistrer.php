<title>SuiviPerf - Enregistrer montre</title>
<?php
    include("../en_tete.php");
?>

<div class="container mt-5 p-4 bg-white rounded-3 shadow" style="max-width:800px;">
    <h1 class="text-center text-success mb-4">Inscrivez vos informations quotidiennes</h1>

    <form action="enregistrerSQL.php" method="get" class="fs-5">
        <div class="mb-3 row align-items-center">
            <label class="col-sm-4 col-form-label">La date</label>
            <div class="col-sm-8">
                <input type="date" name="date" class="form-control" 
                       value="<?php echo date('Y-m-d'); ?>">
            </div>
        </div>

        <div class="mb-3 row align-items-center">
            <label class="col-sm-4 col-form-label">Énergie</label>
            <div class="col-sm-8">
                <input type="text" name="energie" class="form-control" placeholder="kcal">
            </div>
        </div>

        <div class="mb-3 row align-items-center">
            <label class="col-sm-4 col-form-label">Temps de la séance</label>
            <div class="col-sm-8">
                <input type="text" name="tempsSeance" class="form-control" placeholder="minutes">
            </div>
        </div>

        <div class="mb-3 row align-items-center">
            <label class="col-sm-4 col-form-label">Temps de sommeil</label>
            <div class="col-sm-8">
                <input type="text" name="tempsSommeil" class="form-control" placeholder="heures">
            </div>
        </div>

        <div class="mb-3 row align-items-center">
            <label class="col-sm-4 col-form-label">Cardio maximum</label>
            <div class="col-sm-8">
                <input type="text" name="CardMax" class="form-control" placeholder="bpm">
            </div>
        </div>

        <div class="mb-3 row align-items-center">
            <label class="col-sm-4 col-form-label">Cardio minimum</label>
            <div class="col-sm-8">
                <input type="text" name="CardMin" class="form-control" placeholder="bpm">
            </div>
        </div>

        <div class="mb-3 row align-items-center">
            <label class="col-sm-4 col-form-label">Cardio moyen</label>
            <div class="col-sm-8">
                <input type="text" name="CardMoyenne" class="form-control" placeholder="bpm">
            </div>
        </div>

        <div class="mb-3 row align-items-center">
            <label class="col-sm-4 col-form-label">Nombre de pas</label>
            <div class="col-sm-8">
                <input type="text" name="NbPas" class="form-control" placeholder="pas">
            </div>
        </div>

        <div class="text-center mt-4">
            <input type="submit" class="btn btn-success btn-lg" value="Ajouter">
        </div>
    </form>
</div>

<!-- Bootstrap CSS si pas déjà inclus -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
