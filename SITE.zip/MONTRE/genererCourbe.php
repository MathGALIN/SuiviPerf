<?php
// On commence par une vérification de la connexion de l'utilisateur
if (!isset($_COOKIE['connecter'])) {
    // Redirection vers une page de connexion si l'utilisateur n'est pas connecté
    exit; 
}

$pseudo = $_COOKIE['connecter'];
$nom_var_id = "chart_" . strtolower($nom_var);
$nom_var_canva = "myChart_" . strtolower($nom_var);

$SQL = "SELECT date, $nom_var FROM montre WHERE pseudo = ?";
$stmt = $conn->prepare($SQL);
$stmt->execute([$pseudo]);
$lesLignes = $stmt->fetchAll(PDO::FETCH_ASSOC);

$data = [
    'dates' => [],
    'variables' => [],
];

foreach ($lesLignes as $valeur) {
    $data['dates'][] = $valeur["date"];
    $data['variables'][] = $valeur[$nom_var];
}

// Dictionnaire pour les noms conviviaux
$userFriendlyNames = [
    "energie" => "Énergie",
    "tempsSeance" => "Temps de Séance",
    "tempsSommeil" => "Temps de Sommeil",
    "CardMax" => "Fréquence Cardiaque Maximale",
    "CardMin" => "Fréquence Cardiaque Minimale",
    "cardMoyenne" => "Fréquence Cardiaque Moyenne",
    "NbPas" => "Nombre de Pas",
];

$userFriendlyName = isset($userFriendlyNames[$nom_var]) ? $userFriendlyNames[$nom_var] : $nom_var;
?>

<div class="chart-container" hidden id="container_<?php echo $nom_var_id; ?>">
    <h3>Évolution de <?php echo $userFriendlyName; ?></h3>
    <canvas id="<?php echo $nom_var_id; ?>"></canvas>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const chartData_<?php echo strtolower($nom_var); ?> = <?php echo json_encode($data); ?>;
    const ctx_<?php echo strtolower($nom_var); ?> = document.getElementById('<?php echo $nom_var_id; ?>').getContext('2d');
    
    new Chart(ctx_<?php echo strtolower($nom_var); ?>, {
        type: 'line',
        data: {
            labels: chartData_<?php echo strtolower($nom_var); ?>.dates,
            datasets: [{
                label: '<?php echo $userFriendlyName; ?>',
                data: chartData_<?php echo strtolower($nom_var); ?>.variables,
                backgroundColor: 'rgba(42, 122, 226, 0.6)',
                borderColor: 'rgba(42, 122, 226, 1)',
                borderWidth: 2,
            }],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    grid: { display: false }
                },
                y: {
                    beginAtZero: true
                }
            }
        }
    });
});
</script>