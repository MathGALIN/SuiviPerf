<title>SuiviPerf - Voir les infos montre</title>
<?php
// Inclusion des fichiers nécessaires
include("../BDD.php");
include("../en_tete.php");
include("../Cdate.php");
?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.2.2/Chart.min.js"></script>

<style>
/* Contexte global */
body {
    font-family: "Segoe UI", Arial, sans-serif;
    background: #f4f7fb;
    margin: 0;
    padding: 0;
    color: #333;
    text-align: center;
}

.container {
    width: 90%;
    max-width: 1200px;
    margin: 30px auto;
}

h2 {
    font-size: 28px;
    color: #2a7ae2;
    margin-bottom: 20px;
}

/* Table responsive */
.table-wrapper {
    overflow-x: auto;
    box-shadow: 0 4px 10px rgba(0,0,0,0.05);
    border-radius: 10px;
    background: #fff;
    padding: 15px;
    margin-top: 40px;
}

table {
    width: 100%;
    border-collapse: collapse;
    border-radius: 10px;
    overflow: hidden;
}

th, td {
    padding: 12px 15px;
    text-align: center;
}

th {
    background: #2a7ae2;
    color: white;
    font-weight: bold;
}

tr:nth-child(even) {
    background: #f9f9f9;
}

tr:hover {
    background: #eef4ff;
    transition: 0.3s;
}

/* Bouton suppression */
.delete-btn {
    background: #e74c3c;
    border: none;
    padding: 8px 12px;
    border-radius: 6px;
    cursor: pointer;
    color: white;
    transition: 0.3s;
}

.delete-btn:hover {
    background: #c0392b;
}

.delete-btn i {
    pointer-events: none;
}

/* Nouveaux styles pour les graphiques et les onglets */
.chart-container {
    height: 400px;
    margin-top: 20px;
    background: #fff;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.05);
}

.tabs {
    display: flex;
    justify-content: center;
    gap: 10px;
    margin-bottom: 20px;
    flex-wrap: wrap;
}

.tab-btn {
    background-color: #f0f0f0;
    border: 1px solid #ccc;
    padding: 10px 15px;
    cursor: pointer;
    border-radius: 20px;
    transition: all 0.3s;
    font-weight: bold;
    color: #555;
}

.tab-btn:hover {
    background-color: #ddd;
}

.tab-btn.active {
    background-color: #2a7ae2;
    color: white;
    border-color: #2a7ae2;
}

</style>

<br>

<div class="container">
    <h2>📊 Suivi des données de votre montre</h2>

    <div class="tabs">
        <button class="tab-btn active" onclick="showTab('energie')">Énergie</button>
        <button class="tab-btn" onclick="showTab('tempsSeance')">Temps de la séance </button>
        <button class="tab-btn" onclick="showTab('tempsSommeil')">Temps de sommeil</button>
        <button class="tab-btn" onclick="showTab('NbPas')">Nombre de pas</button>
    </div>

    <div class="tabs">
        <button class="tab-btn" onclick="showTab('CardMax')">Fréquence cardiaque maximale</button>
        <button class="tab-btn" onclick="showTab('CardMin')">Fréquence cardiaque minimale</button>
        <button class="tab-btn" onclick="showTab('cardMoyenne')">Fréquence cardiaque moyenne</button>
    </div>

    <?php
    $idHide = 1;
    $nom_var = "energie";
    include("genererCourbe.php");

    $idHide = 2;
    $nom_var = "tempsSeance";
    include("genererCourbe.php");

    $idHide = 3;
    $nom_var = "tempsSommeil";
    include("genererCourbe.php");

    $idHide = 4;
    $nom_var = "CardMax";
    include("genererCourbe.php");

    $idHide = 5;
    $nom_var = "CardMin";
    include("genererCourbe.php");

    $idHide = 6;
    $nom_var = "cardMoyenne";
    include("genererCourbe.php");

    $idHide = 7;
    $nom_var = "NbPas";
    include("genererCourbe.php");
    ?>
</div>

<div class="container">
    <div class="table-wrapper">
        <table>
            <tr>
                <th>Date</th>
                <th>Énergie</th>
                <th>Temps de la séance</th>
                <th>Temps de sommeil</th>
                <th>Fréquence cardiaque maximale</th>
                <th>Fréquence cardiaque minimale</th>
                <th>Fréquence cardiaque moyenne</th>
                <th>Nombre de pas</th>
                <th>Supprimer</th>
            </tr>
            <?php
            $lesLignes = $CBDD_SuiviPerf->GetInfoMontre();
            foreach ($lesLignes as $valeur) {
                $Date = new Cdate($valeur["date"], $pseudo);
                $labelDate = $Date->GetDate();
                $an = $Date->An;
                $mois = $Date->Mois;
                $jour = $Date->Jour;

                $energie = $valeur["energie"];
                $tempsSeance = $valeur["tempsSeance"];
                $tempsSommeil = $valeur["tempsSommeil"];
                $CardMax = $valeur["CardMax"];
                $CardMin = $valeur["CardMin"];
                $cardMoyenne = $valeur["CardMoyenne"];
                $NbPas = $valeur["NbPas"];

                echo "
                <tr>
                    <td>$labelDate</td>
                    <td>$energie</td>
                    <td>$tempsSeance</td>
                    <td>$tempsSommeil</td>
                    <td>$CardMax</td>
                    <td>$CardMin</td>
                    <td>$cardMoyenne</td>
                    <td>$NbPas</td>
                    <td align='center'>
                        <button class='delete-btn' onclick='Supprimer($an, $mois, $jour)'>
                            <i class='fas fa-trash'></i>
                        </button>
                    </td>
                </tr>
                ";
            }
            ?>
        </table>
    </div>
</div>

<script>
function showTab(variable) {
    const allCharts = document.querySelectorAll('.chart-container');
    allCharts.forEach(chart => {
        chart.hidden = true;
    });

    const activeChart = document.getElementById('container_chart_' + variable.toLowerCase());
    if (activeChart) {
        activeChart.hidden = false;
    }

    const allTabs = document.querySelectorAll('.tab-btn');
    allTabs.forEach(tab => {
        tab.classList.remove('active');
    });

    const activeTab = document.querySelector(`.tab-btn[onclick*="${variable}"]`);
    if (activeTab) {
        activeTab.classList.add('active');
    }
}

document.addEventListener('DOMContentLoaded', function() {
    showTab('energie');
});

function Supprimer(an, mois, jour) {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette entrée ?')) {
        document.location.href = 'SupprimerMontreSQL.php?an=' + an + '&mois=' + mois + '&jour=' + jour;
    }
}
</script>